/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

import java.util.Arrays;
import java.util.LinkedList;
import largescaletesis.algorithm.VIIC;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class TestVIIC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FunctionsSayed fs = new FunctionsSayed(1,100);
        VIIC viic = new VIIC(5,fs);
        long i = System.currentTimeMillis();
        System.out.println(Arrays.toString(viic.getDecomposition(false)));
        //System.out.println(Arrays.toString(viic.getrandGprspool()));
        System.out.println(System.currentTimeMillis()-i);

//        LinkedList<Integer> Sn = new LinkedList<>();
//        int i = 5;
//        Sn.add(1);
//        Sn.add(new Integer(2));
//        Sn.add(i);
//        
//        int j = 5;
//        
//        System.out.println(Sn.contains(3));
//        System.out.println(Sn.contains(j));
//        System.out.println(Sn.contains(5));
        
        System.out.println((int)Math.ceil(33.33));
    }
    
}

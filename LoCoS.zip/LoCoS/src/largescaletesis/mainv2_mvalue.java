/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

import evoutils.functions.IFunctionEvaluation;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import largescaletesis.algorithm.DELODES;
import largescaletesis.algorithm.DELOCOS;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class mainv2_mvalue extends ForkJoinTask {

    int[] function = {1};
    int runs = 1;

    double F = 0.5, CR = 0.9;
    int NP = 100;

    int MaxFes = 10000000;
    int dimension = 500;
    String folder = "./test/d500/";
    int m = 2;

    public mainv2_mvalue(int[] function, int dimension, double F, double CR, int NP, int MaxFes, int runs, String folder, int m) {
        this.function = function;
        this.dimension = dimension;
        this.F = F;
        this.CR = CR;
        this.NP = NP;
        this.MaxFes = MaxFes;
        this.runs = runs;
        this.folder = folder;
        this.m = m;
    }

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        //int[] function = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
        int[] function = {3, 6, 9, 12, 15, 18};

        int exp = 8;
//        String folderExpd100 = "./test/Exp" + exp + "d100/";
//        String folderExpd500 = "./test/Exp" + exp + "d500/";
//        String folderExpd1000 = "./test/Exp" + exp + "d1000/";
        //int[] function = {1};
        int runs = 10;

        double F = 0.5, CR = 0.9;
        int NP = 100;
        int[] ms = {2,3,4,6,8};
        int MaxFes100 = 2000000;
        int MaxFes500 = 7500000;
        int MaxFes1000 = 7500000;
        
        
        for (int i = 0; i < ms.length; i++) {

            String folderExpd100 = "./test/Exp" + exp + "d100_M_"+ms[i]+"/";
            String folderExpd500 = "./test/Exp" + exp + "d500_M_"+ms[i]+"/";
            String folderExpd1000 = "./test/Exp" + exp + "d1000_M_"+ms[i]+"/";

            ForkJoinPool pool = new ForkJoinPool(Runtime.getRuntime().availableProcessors());

            mainv2_mvalue test100 = new mainv2_mvalue(function, 100, F, CR, NP, MaxFes100, runs, folderExpd100, ms[i]);
            mainv2_mvalue test500 = new mainv2_mvalue(function, 500, F, CR, NP, MaxFes500, runs, folderExpd500, ms[i]);
            mainv2_mvalue test1000 = new mainv2_mvalue(function, 1000, F, CR, NP, MaxFes1000, runs, folderExpd1000, ms[i]);

            pool.execute(test100);
            pool.execute(test500);
            pool.execute(test1000);

            do {
                System.out.printf("******************************************\n");
                System.out.printf("Main: Active Threads: %d\n", pool.getActiveThreadCount());
                System.out.printf("Main: Steal Count: %d\n", pool.getStealCount());
                System.out.printf("******************************************\n");
                try {
                    TimeUnit.MINUTES.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (
                    (!test100.isDone()) 
                    || (!test500.isDone()) 
                    || (!test1000.isDone())
                    );
        }
    }

    public void runexp(int[] function, int dimension, double F, double CR, int NP, int MaxFes, int runs, String folder, int m) {
        for (int i = 0; i < function.length; i++) {
            IFunctionEvaluation f = new FunctionsSayed(function[i], dimension);
            ExperimentRuns er4 = new ExperimentRuns(folder, "mmde_exp4", f.getFunctionName());
            ExperimentRuns er5 = new ExperimentRuns(folder, "mmde_exp5", f.getFunctionName());
            for (int e = 0; e < runs; e++) {
                System.out.println("Function: " + f.getFunctionName() + " Run: " + e);
                DELOCOS mdde5 = new DELOCOS(this.F, this.CR, this.NP, this.MaxFes, this.dimension, m);
                DELODES mdde4 = new DELODES(this.F, this.CR, this.NP, this.MaxFes, this.dimension, m);
                //MemeticDecompositionDE1_exp3 mdde = new MemeticDecompositionDE1_exp3(F, CR, NP, MaxFes, dimension);
                //MemeticDecompositionDE1_exp2 mdde = new MemeticDecompositionDE1_exp2(F, CR, NP, MaxFes, dimension);
                
                mdde5.setFunction(f);
                mdde4.setFunction(f);
                
                RunResults r4 = mdde4.run();
                System.out.println(Arrays.toString(r4.getFinalbestF()));
                er4.addRunResult(r4);
                
                RunResults r5 = mdde5.run();
                System.out.println(Arrays.toString(r5.getFinalbestF()));
                er5.addRunResult(r5);
                
            }
            er4.exportData();
            er5.exportData();
        }
    }

    public void run() {
        runexp(function, dimension, F, CR, NP, MaxFes, runs, folder, m);
    }

    @Override
    public Object getRawResult() {
        return null;
    }

    @Override
    protected void setRawResult(Object value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected boolean exec() {
        this.run();
        return true;
    }

}

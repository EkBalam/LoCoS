/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;
import evoutils.functions.IFunctionEvaluation;
import largescaletesis.algorithm.DELOCOS;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.cli.*;

/**
 *
 * @author Adan
 */
public class TunningIrace {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        Options options = new Options();

        Option f_value = new Option("F", "F", true, "F");
        f_value.setRequired(true);
        options.addOption(f_value);

        Option cr_value = new Option("CR", "CR", true, "CR");
        cr_value.setRequired(true);
        options.addOption(cr_value);
        
        Option np_value = new Option("NP", "NP", true, "NP");
        np_value.setRequired(true);
        options.addOption(np_value);
        
        Option d_value = new Option("D", "Dimension", true, "D");
        d_value.setRequired(true);
        options.addOption(d_value);
        
        Option funct_value = new Option("Funct", "Function", true, "Function");
        funct_value.setRequired(true);
        options.addOption(funct_value);
        
//        Option alg_value = new Option("Alg", "algorithm", true, "algorithm");
//        alg_value.setRequired(true);
//        options.addOption(alg_value);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
            return;
        }

        double F = Double.valueOf(cmd.getOptionValue("F"));
        double CR = Double.valueOf(cmd.getOptionValue("CR"));
        int    NP = Integer.valueOf(cmd.getOptionValue("NP"));
        int    function = Integer.valueOf(cmd.getOptionValue("Funct"));
        int    dimension = Integer.valueOf(cmd.getOptionValue("D"));
        int m = 2;

        
        int MaxFes = 2000000;

        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        DELOCOS mdde = new DELOCOS(F, CR, NP, MaxFes, dimension, m);
        mdde.setFunction(f);
        RunResults r4 = mdde.run();
        
        System.out.println(r4.getFinalbestF()[0]+ 100000*r4.getFinalbestF()[1]);
       
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

/**
 *
 * @author Adan
 */
public class Time0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        long ti = System.currentTimeMillis();
        for(int i = 0 ; i < 1000000; i++){
            double x = 5.55;
            x = x+x;
            x = x/2;
            x = x*x;
            x = Math.sqrt(x);
            x = Math.log(x);
            x = Math.exp(x);
            double y = x/x;
        }
        long t = System.currentTimeMillis()-ti;
        System.out.println(t/1000.0);
        System.out.printf("Time : %.1e \n",(t/1000.0));
    }
    
}

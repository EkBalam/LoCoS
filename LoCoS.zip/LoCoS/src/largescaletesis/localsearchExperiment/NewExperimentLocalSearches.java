/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.localsearchExperiment;

import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import java.util.Arrays;
import largescaletesis.algorithm.VIIC;
import largescaletesis.algorithm.differentialgrouping2.DifferentialGrouping2;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;
import largescaletesis.algorithm.localsearch.NelderMead;
import largescaletesis.algorithm.localsearch.RandomWalk;
import largescaletesis.functions.constrained.FunctionsSayed;
import viicstay.VIICSearch;
import viicstay.representation.Dvector;

/**
 *
 * @author Adan
 */
public class NewExperimentLocalSearches {

    public static void main(String[] args) throws IOException {
        int runs = 25;
        int funciones = 18;
        int dimension = args.length > 0 ? Integer.valueOf(args[0]) : 100;
        int maxfes = 20000 * dimension;
        int m = 2;

        String folder = "./resultsLS/";

        String fileHJ_f = "";
        String HJ_F_R = "";
        String fileHJ_cvs = "";
        String HJ_CVS_R = "";
        String fileHJ_fes = "";
        String HJ_FES_R = "";

        String fileNM_f = "";
        String NM_F_R = "";
        String fileNM_cvs = "";
        String NM_CVS_R = "";
        String fileNM_fes = "";
        String NM_FES_R = "";

        String fileRW_f = "";
        String RW_F_R = "";
        String fileRW_cvs = "";
        String RW_CVS_R = "";
        String fileRW_fes = "";
        String RW_FES_R = "";
        
        String FES_VIIC = "";
        
        String decomp = "";

        Solution.PRINT_X = false;
        FunctionsSayed f = null;
        Solution s = null;

        HookeJeevesM HJ = new HookeJeevesM(2, maxfes, f);
        HJ.setCyclesMax(Integer.MAX_VALUE / 2);

        NelderMead NM = new NelderMead(1, 0.5, 1.5, 0.0001, f,
                Integer.MAX_VALUE, maxfes, maxfes);

        RandomWalk RW = new RandomWalk(100, dimension, 0.0001, f,
                Integer.MAX_VALUE, Integer.MAX_VALUE);

        VIIC viic = null;
        VIICSearch viics = null;
        DifferentialGrouping2 dg2 = null;

        int[] variables = null;
        int[] variablesSubgroups = null;

        for (int de = 0; de < 4; de++) {

            decomp = "nodecom";
            switch (de) {
                case 0:
                    decomp = "VIIC";
                    break;
                case 1:
                    decomp = "DVIIC";
                    break;
                case 2:
                    decomp = "DG2";
                    break;
                case 3:
                    //NO DESCOMPOSITION
                    decomp = "nodecom";
                    break;
            }

            fileHJ_f = folder + dimension + "_" + decomp + "DataHJ_f.will";
            fileHJ_cvs = folder + dimension + "_" + decomp + "DataHJ_cvs.will";
            fileHJ_fes = folder + dimension + "_" + decomp + "DataHJ_fes.will";

            fileNM_f = folder + dimension + "_" + decomp + "DataNM_f.will";
            fileNM_cvs = folder + dimension + "_" + decomp + "DataNM_cvs.will";
            fileNM_fes = folder + dimension + "_" + decomp + "DataNM_fes.will";

            fileRW_f = folder + dimension + "_" + decomp + "DataRW_f.will";
            fileRW_cvs = folder + dimension + "_" + decomp + "DataRW_cvs.will";
            fileRW_fes = folder + dimension + "_" + decomp + "DataRW_fes.will";

            for (int j = 0; j < funciones; j++) {
                f = new FunctionsSayed(j + 1, dimension);
                HJ.setFunction(f);
                NM.setFunction(f);
                RW.setFunction(f);
                
                HJ_F_R = "";
                HJ_CVS_R = "";
                HJ_FES_R = "";

                NM_F_R = "";
                NM_CVS_R = "";
                NM_FES_R = "";

                RW_F_R = "";
                RW_CVS_R = "";
                RW_FES_R = "";
                
                FES_VIIC = "";

                for (int r = 0; r < runs; r++) {

                    switch (de) {
                        case 0:
                            viic = new VIIC(m, f);
                            variables = viic.getDecomposition(true);
                            variablesSubgroups = viic.getV();
                            FES_VIIC += " "+viic.getEvalsObjectiveFunction();
                            break;
                        case 1:
                            int fes_viic = (int) ((int) ((dimension * (dimension + 1.0)) / 2.0) + 1.0);
                            viics = new VIICSearch(6, 0.9, 0.2, fes_viic, f);
                            viics.run(null);
                            variables = viics.getBest().getArrangement();
                            variablesSubgroups = viics.getBest().getVsubproblemSizes();
                            break;
                        case 2:
                            //DECOMPOSITION
                            dg2 = new DifferentialGrouping2(f);
                            int[] group = dg2.groups(dg2.tetha, f.getDimension());
                            Dvector des = new Dvector(f.getDimension());
                            des.setVarArrGroup(group);
                            variables = des.getArrangement();
                            variablesSubgroups = des.getVsubproblemSizes();
                            break;
                        case 3:
                            //NO DESCOMPOSITION
                            variablesSubgroups = new int[1];
                            variablesSubgroups[0] = f.getDimension();
                            variables = new int[f.getDimension()];
                            for (int v = 0; v < f.getDimension(); v++) {
                                variables[v] = v;
                            }
                            break;
                    }

                    s = new Solution(dimension, f.getNumberIConstraints(),
                            f.getNumberEConstraints());
                    s.setX(Utils.generateVectorRandom(dimension, f.getLimits()));
                    f.evaluate(s);

                    Solution sNM = s.clone();
                    Solution sRW = s.clone();

                    System.out.println("----------  Function " + f.getFunctionName()
                            + " Run: " + r + "       ----------");
                    System.out.println(s);

                    m = variablesSubgroups.length;
                    int to = 0;
                    int from = 0;

                    int totalEvalsHJ = 0;
                    int totalEvalsNM = 0;
                    int totalEvalsRW = 0;

                    for (int k = 0; k < m; k++) {
                        to = from + variablesSubgroups[k];
                        int[] varSub = Arrays.copyOfRange(variables, from, to);

                        double base = de == 3 ? 180 : 0.5;

                        LocalSearchResult lsr = HJ.localSearch(s, varSub, base, 0);

                        LocalSearchResult lsrNM = NM.localSearch(sNM, varSub, 0);

                        LocalSearchResult lsrRW = RW.localSearch(sRW, varSub, 0);

                        s = lsr.result;
                        sNM = lsrNM.result;
                        sRW = lsrRW.result;

                        totalEvalsHJ += lsr.FEs;
                        totalEvalsNM += lsrNM.FEs;
                        totalEvalsRW += lsrRW.FEs;

                        from = to;
                    }

                    System.out.println("------------------HOOKE JEEVES----------------");
                    System.out.println(s);
                    System.out.println(totalEvalsHJ);
                    System.out.println("------------------NELDER MEAD-----------------");
                    System.out.println(sNM);
                    System.out.println(totalEvalsNM);
                    System.out.println("------------------RANDOM WALK-----------------");
                    System.out.println(sRW);
                    System.out.println(totalEvalsRW);

                    HJ_F_R += "" + s.getF() + " ";
                    HJ_CVS_R += "" + s.getSvr() + " ";
                    HJ_FES_R += "" + totalEvalsHJ + " ";

                    NM_F_R += "" + sNM.getF() + " ";
                    NM_CVS_R += "" + sNM.getSvr() + " ";
                    NM_FES_R += "" + totalEvalsNM + " ";

                    RW_F_R += "" + sRW.getF() + " ";
                    RW_CVS_R += "" + sRW.getSvr() + " ";
                    RW_FES_R += "" + totalEvalsRW + " ";

                }
                
                HJ_F_R = "Hooke_Jeeves_"+decomp+";" + f.getFunctionName() + ";[ "+HJ_F_R+"];";                
                SaveDataFile.saveStringln(fileHJ_f, HJ_F_R);
                HJ_CVS_R = "Hooke_Jeeves_"+decomp+";" + f.getFunctionName() + ";[ "+HJ_CVS_R+"];";                
                SaveDataFile.saveStringln(fileHJ_cvs, HJ_CVS_R);
                HJ_FES_R = "Hooke_Jeeves_"+decomp+";" + f.getFunctionName() + ";[ "+HJ_FES_R+"];";                
                SaveDataFile.saveStringln(fileHJ_fes, HJ_FES_R);
                
                NM_F_R = "Nelder_Mead_"+decomp+";" + f.getFunctionName() + ";[ "+NM_F_R+"];";
                SaveDataFile.saveStringln(fileNM_f, NM_F_R);
                NM_CVS_R = "Nelder_Mead_"+decomp+";" + f.getFunctionName() + ";[ "+NM_CVS_R+"];";                
                SaveDataFile.saveStringln(fileNM_cvs, NM_CVS_R);
                NM_FES_R = "Nelder_Mead_"+decomp+";" + f.getFunctionName() + ";[ "+NM_FES_R+"];";            
                SaveDataFile.saveStringln(fileNM_fes, NM_FES_R);
                
                RW_F_R = "Random_Walk_"+decomp+";" + f.getFunctionName() + ";[ "+RW_F_R+"];";        
                SaveDataFile.saveStringln(fileRW_f, RW_F_R);
                RW_CVS_R = "Random_Walk_"+decomp+";" + f.getFunctionName() + ";[ "+RW_CVS_R+"];";                
                SaveDataFile.saveStringln(fileRW_cvs, RW_CVS_R);
                RW_FES_R = "Random_Walk_"+decomp+";" + f.getFunctionName() + ";[ "+RW_FES_R+"];";
                SaveDataFile.saveStringln(fileRW_fes, RW_FES_R);
                
                if(!FES_VIIC.equals("")){
                    SaveDataFile.saveString(folder+"VIIC_FES_"+ f.getFunctionName()+".txt", "VIIC_FES;"+FES_VIIC);
                }
            }

        }

    }

}

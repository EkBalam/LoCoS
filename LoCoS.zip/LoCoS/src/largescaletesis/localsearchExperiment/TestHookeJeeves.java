/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.localsearchExperiment;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import java.util.Arrays;
import largescaletesis.algorithm.VIIC;
import largescaletesis.algorithm.differentialgrouping2.DifferentialGrouping2;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;
import largescaletesis.algorithm.localsearch.NelderMead;
import largescaletesis.algorithm.localsearch.RandomWalk;
import largescaletesis.functions.constrained.FunctionsSayed;
import viicstay.VIICSearch;
import viicstay.representation.Dvector;

/**
 *
 * @author EkBalam
 */
public class TestHookeJeeves {

    
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        int runs = 25;

        int dimension = 500;
        int descomposicion = 4;

        if (args.length > 0) {
            dimension = Integer.valueOf(args[0]);
            descomposicion = Integer.valueOf(args[1]);
        }

        int maxfes = (int)(20000 * dimension * 0.3);
        System.out.println("Max Fes = "+maxfes);
        int m = 2;

        String fileHJ_f = "./resultsHokeJeeves/DataHJ_f" + dimension + ".will";
        String fileHJ_cvs = "./resultsHokeJeeves/DataHJ_cvs" + dimension + ".will";
        String fileHJ_fes = "./resultsHokeJeeves/DataHJ_fes" + dimension + ".will";

        for (int j = 0; j < 18; j++) {
            FunctionsSayed f = new FunctionsSayed(j + 1, dimension);

            SaveDataFile.saveString(fileHJ_f, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileHJ_cvs, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileHJ_fes, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");

            Solution.PRINT_X = false;

            for (int i = 0; i < runs; i++) {
                Solution s = new Solution(dimension, f.getNumberIConstraints(), f.getNumberEConstraints());
                s.setX(Utils.generateVectorRandom(dimension, f.getLimits()));
                f.evaluate(s);

                System.out.println("--------------------------------------------");
                System.out.println(s);

                int[] variables = null;
                int[] variablesSubgroups = null;

                switch (descomposicion) {
                    case 1:
                        VIIC viic = new VIIC(m, f);
                        variables = viic.getDecomposition(true);
                        variablesSubgroups = viic.getV();
                        break;
                    case 2:
                        int fes_viic = (int) (maxfes * 0.1);
                        VIICSearch viics = new VIICSearch(6, 0.9, 0.2, fes_viic, f);
                        viics.run(null);
                        variables = viics.getBest().getArrangement();
                        variablesSubgroups = viics.getBest().getVsubproblemSizes();
                        break;
                    case 3:
                        //DECOMPOSITION
                        DifferentialGrouping2 dg2 = new DifferentialGrouping2(f);
                        int[] group = dg2.groups(dg2.tetha, f.getDimension());
                        Dvector des = new Dvector(f.getDimension());
                        des.setVarArrGroup(group);
                        variables = des.getArrangement();
                        variablesSubgroups = des.getVsubproblemSizes();
                        break;
                    case 4:
                        //NO DESCOMPOSITION
                        variablesSubgroups = new int[1];
                        variablesSubgroups[0] = f.getDimension();
                        variables = new int[f.getDimension()];
                        for (int v = 0; v < f.getDimension(); v++) {
                            variables[v] = v;
                        }

                }

                m = variablesSubgroups.length;

                int to = 0;
                int from = 0;

                HookeJeevesM ls = new HookeJeevesM(2, maxfes, f);
                ls.setCyclesMax(Integer.MAX_VALUE / 2);

                int totalEvalsHJ = 0;

                //Subgroups
                for (int k = 0; k < m; k++) {
                    to = from + variablesSubgroups[k];
                    int[] varSub = Arrays.copyOfRange(variables, from, to);

                    //System.out.println(Arrays.toString(varSub));
                    LocalSearchResult lsr = ls.localSearch(s, varSub, 180, 0);
                    System.out.println("eps = " + ls.getEps());

                    s = lsr.result;

                    totalEvalsHJ += lsr.FEs;

                    from = to;
                }
                System.out.println("------------------HOOKE JEEVES----------------");
                System.out.println(s);
                System.out.println(totalEvalsHJ);

                SaveDataFile.saveString(fileHJ_f, "" + s.getF() + " ");
                SaveDataFile.saveString(fileHJ_cvs, "" + s.getSvr() + " ");
                SaveDataFile.saveString(fileHJ_fes, "" + totalEvalsHJ + " ");

            }
            SaveDataFile.saveStringln(fileHJ_f, "];");
            SaveDataFile.saveStringln(fileHJ_cvs, "];");
            SaveDataFile.saveStringln(fileHJ_fes, "];");

        }

    }

}

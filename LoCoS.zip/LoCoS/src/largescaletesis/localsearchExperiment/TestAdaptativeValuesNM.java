/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.localsearchExperiment;

import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import java.util.Arrays;
import largescaletesis.algorithm.VIIC;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;
import largescaletesis.algorithm.localsearch.NelderMead;
import largescaletesis.algorithm.localsearch.RandomWalk;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class TestAdaptativeValuesNM {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int runs = 25;
        //int maxfes = 20000000;
        //int maxfes = 10000000;
        int maxfes = 2000000;
        int dimension = 100;
        int m = 2;
        
        String fileNM1 = "DataNM1"+dimension+".m";
        String fileNM2 = "DataNM2"+dimension+".m";
        
        
        for (int j = 0; j < 18; j++) {
            FunctionsSayed f = new FunctionsSayed(j + 1, dimension);
            SaveDataFile.saveString(fileNM1, "runsNM1F"+(j+1)+" = [");
            SaveDataFile.saveString(fileNM2, "runsNM2F"+(j+1)+" = [");
            
            for (int i = 0; i < runs; i++) {    
                Solution s = new Solution(dimension, f.getNumberIConstraints(), f.getNumberEConstraints());
                s.setX(Utils.generateVectorRandom(dimension, f.getLimits()));
                f.evaluate(s);
                
                Solution sNM1 = s.clone();
                Solution sNM2 = s.clone();
                
                System.out.println("--------------------------------------------");
                System.out.println(s);

                VIIC viic = new VIIC(m, f);
                int[] variables = viic.getDecomposition(true);
                int[] variablesSubgroups = viic.getV();
                int to = 0;
                int from = 0;

                
                NelderMead NM1 = new NelderMead(1, 0.5, 2, 0.0001, f, Integer.MAX_VALUE, maxfes, maxfes);
                NelderMead NM2 = new NelderMead(1, (0.75-(1/(2*(dimension/m)))), (1+(2/(dimension/m))), 0.0001, f, Integer.MAX_VALUE, maxfes, maxfes);
                
                int totalEvalsNM1 = 0;
                int totalEvalsNM2 = 0;                
                
                //Subgroups
                for (int k = 0; k < m; k++) {
                    to = from + variablesSubgroups[k];
                    int[] varSub = Arrays.copyOfRange(variables, from, to);
                    
                    //System.out.println(Arrays.toString(varSub));

                    LocalSearchResult lsrNM1 = NM1.localSearch(sNM1, varSub, 0);
                    LocalSearchResult lsrNM2 = NM2.localSearch(sNM2, varSub, 0);
                                        
                    sNM1 = lsrNM1.result;
                    sNM2 = lsrNM2.result;                    
                    
                    totalEvalsNM1 += lsrNM1.FEs;
                    totalEvalsNM2 += lsrNM2.FEs;
                    
                    from = to;
                }
                System.out.println("------------------NELDER MEAD 1-----------------");
                System.out.println(sNM1);
                System.out.println(totalEvalsNM1);
                System.out.println("------------------NELDER MEAD 2-----------------");
                System.out.println(sNM2);
                System.out.println(totalEvalsNM2);
                
                SaveDataFile.saveString(fileNM1, ""+sNM1.getF()+","+sNM1.getSvr()+","+totalEvalsNM1+";");
                SaveDataFile.saveString(fileNM2, ""+sNM2.getF()+","+sNM2.getSvr()+","+totalEvalsNM2+";");

            }
            SaveDataFile.saveStringln(fileNM1, "];");
            SaveDataFile.saveStringln(fileNM2, "];");

        }

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.localsearchExperiment;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import java.util.Arrays;
import largescaletesis.algorithm.VIIC;
import largescaletesis.algorithm.differentialgrouping2.DifferentialGrouping2;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;
import largescaletesis.algorithm.localsearch.NelderMead;
import largescaletesis.algorithm.localsearch.RandomWalk;
import largescaletesis.functions.constrained.FunctionsSayed;
import viicstay.VIICSearch;
import viicstay.representation.Dvector;

/**
 *
 * @author EkBalam
 */
public class TestLocalSearches {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        int runs = 25;

        int dimension = Integer.valueOf(args[0]);

        int descomposicion = Integer.valueOf(args[1]);

        int maxfes = 20000 * dimension;
        int m = 2;

        String fileHJ_f = "./resultsLS/DataHJ_f" + dimension + ".will";
        String fileHJ_cvs = "./resultsLS/DataHJ_cvs" + dimension + ".will";
        String fileHJ_fes = "./resultsLS/DataHJ_fes" + dimension + ".will";
        
        String fileNM_f = "./resultsLS/DataNM_f" + dimension + ".will";
        String fileNM_cvs = "./resultsLS/DataNM_cvs" + dimension + ".will";
        String fileNM_fes = "./resultsLS/DataNM_fes" + dimension + ".will";

        String fileRW_f = "./resultsLS/DataRW_f" + dimension + ".will";
        String fileRW_cvs = "./resultsLS/DataRW_cvs" + dimension + ".will";
        String fileRW_fes = "./resultsLS/DataRW_fes" + dimension + ".will";
        
        
        

        for (int j = 0; j < 18; j++) {
            FunctionsSayed f = new FunctionsSayed(j + 1, dimension);

            SaveDataFile.saveString(fileHJ_f, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileHJ_cvs, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileHJ_fes, "Hooke_Jeeves;" + f.getFunctionName() + ";[ ");

            SaveDataFile.saveString(fileNM_f, "Nelder_Mead;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileNM_cvs, "Nelder_Mead;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileNM_fes, "Nelder_Mead;" + f.getFunctionName() + ";[ ");

            SaveDataFile.saveString(fileRW_f, "Random_Walk;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileRW_cvs, "Random_Walk;" + f.getFunctionName() + ";[ ");
            SaveDataFile.saveString(fileRW_fes, "Random_Walk;" + f.getFunctionName() + ";[ ");

            Solution.PRINT_X = false;

            for (int i = 0; i < runs; i++) {
                Solution s = new Solution(dimension, f.getNumberIConstraints(), f.getNumberEConstraints());
                s.setX(Utils.generateVectorRandom(dimension, f.getLimits()));
                f.evaluate(s);

                Solution sNM = s.clone();
                Solution sRW = s.clone();

                System.out.println("--------------------------------------------");
                System.out.println(s);

                int[] variables = null;
                int[] variablesSubgroups = null;

                switch (descomposicion) {
                    case 1:
                        VIIC viic = new VIIC(m, f);
                        variables = viic.getDecomposition(true);
                        variablesSubgroups = viic.getV();
                        break;
                    case 2:
                        int fes_viic = (int)( (int)((dimension*(dimension + 1.0)) / 2.0 )+ 1.0 );
                        VIICSearch viics = new VIICSearch(6, 0.9, 0.2, fes_viic, f);
                        viics.run(null);
                        variables = viics.getBest().getArrangement();
                        variablesSubgroups = viics.getBest().getVsubproblemSizes();
                        break;
                    case 3:
                        //DECOMPOSITION
                        DifferentialGrouping2 dg2 = new DifferentialGrouping2(f);
                        int[] group = dg2.groups(dg2.tetha, f.getDimension());
                        Dvector des = new Dvector(f.getDimension());
                        des.setVarArrGroup(group);
                        variables = des.getArrangement();
                        variablesSubgroups = des.getVsubproblemSizes();
                        break;
                    case 4: 
                        //NO DESCOMPOSITION
                        variablesSubgroups = new int[1];
                        variablesSubgroups[0] = f.getDimension();
                        variables = new int[f.getDimension()];
                        for(int v = 0; v < f.getDimension(); v++){
                            variables[v] = v;
                        }
                }

                m = variablesSubgroups.length;
                
                int to = 0;
                int from = 0;

                HookeJeevesM hjnod = new HookeJeevesM(2, maxfes, f);
                hjnod.setCyclesMax(Integer.MAX_VALUE / 2);
                
                HookeJeevesM ls = new HookeJeevesM(2, maxfes, f);
                ls.setCyclesMax(Integer.MAX_VALUE / 2);

                NelderMead NMnode = new NelderMead(1, 0.5, 1.5, 0.0001, f, Integer.MAX_VALUE, maxfes, maxfes);
                NelderMead NM = new NelderMead(1, 0.5, 1.5, 0.0001, f, Integer.MAX_VALUE, maxfes, maxfes);

                RandomWalk RWnode = new RandomWalk(100, dimension, 0.0001, f, Integer.MAX_VALUE, Integer.MAX_VALUE);
                RandomWalk RW = new RandomWalk(100, dimension, 0.0001, f, Integer.MAX_VALUE, Integer.MAX_VALUE);

                int totalEvalsHJ = 0;
                int totalEvalsNM = 0;
                int totalEvalsRW = 0;

                //Subgroups
                for (int k = 0; k < m; k++) {
                    to = from + variablesSubgroups[k];
                    int[] varSub = Arrays.copyOfRange(variables, from, to);

                    LocalSearchResult lsrHjnD = hjnod.localSearch(s, variables, 180, 0);
                    System.out.println("eps no des= " + hjnod.getEps());
                    
                    //System.out.println(Arrays.toString(varSub));
                    LocalSearchResult lsr = ls.localSearch(s, varSub, 0.5, 0);
                    System.out.println("eps = " + ls.getEps());

                    LocalSearchResult lsrNM = NM.localSearch(sNM, varSub, 0);

                    LocalSearchResult lsrRW = RW.localSearch(sRW, varSub, 0);

                                       
                    s = lsr.result;
                    sNM = lsrNM.result;
                    sRW = lsrRW.result;

                    totalEvalsHJ += lsr.FEs;
                    totalEvalsNM += lsrNM.FEs;
                    totalEvalsRW += lsrRW.FEs;

                    from = to;
                }
                System.out.println("------------------HOOKE JEEVES----------------");
                System.out.println(s);
                System.out.println(totalEvalsHJ);
                System.out.println("------------------NELDER MEAD-----------------");
                System.out.println(sNM);
                System.out.println(totalEvalsNM);
                System.out.println("------------------RANDOM WALK-----------------");
                System.out.println(sRW);
                System.out.println(totalEvalsRW);

                SaveDataFile.saveString(fileHJ_f, "" + s.getF() + " ");
                SaveDataFile.saveString(fileHJ_cvs, "" + s.getSvr() + " ");
                SaveDataFile.saveString(fileHJ_fes, "" + totalEvalsHJ + " ");

                SaveDataFile.saveString(fileNM_f, "" + sNM.getF() + " ");
                SaveDataFile.saveString(fileNM_cvs, "" + sNM.getSvr() + " ");
                SaveDataFile.saveString(fileNM_fes, "" + totalEvalsNM + " ");

                SaveDataFile.saveString(fileRW_f, "" + sRW.getF() + " ");
                SaveDataFile.saveString(fileRW_cvs, "" + sRW.getSvr() + " ");
                SaveDataFile.saveString(fileRW_fes, "" + totalEvalsRW + " ");

            }
            SaveDataFile.saveStringln(fileHJ_f, "];");
            SaveDataFile.saveStringln(fileHJ_cvs, "];");
            SaveDataFile.saveStringln(fileHJ_fes, "];");

            SaveDataFile.saveStringln(fileNM_f, "];");
            SaveDataFile.saveStringln(fileNM_cvs, "];");
            SaveDataFile.saveStringln(fileNM_fes, "];");

            SaveDataFile.saveStringln(fileRW_f, "];");
            SaveDataFile.saveStringln(fileRW_cvs, "];");
            SaveDataFile.saveStringln(fileRW_fes, "];");

        }

    }
    private IFunctionEvaluation function;

}

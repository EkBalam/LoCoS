/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import largescaletesis.algorithm.DELOCOS;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class LargeScaleTesis extends ForkJoinTask{

    int func = 18;
    double F = 0.5, CR = 0.9;
    int NP = 100;
    int MaxFes = 2000000;
    int dimension = 100;

    public LargeScaleTesis(int func, double F, double CR, int NP, int MaxFes, int dimension) {
        this.func = func;
        this.F = F;
        this.CR = CR;
        this.NP = NP;
        this.MaxFes = MaxFes;
        this.dimension = dimension;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        
        ForkJoinPool pool = new ForkJoinPool(Runtime.getRuntime().availableProcessors());
        
        LargeScaleTesis d100 = new LargeScaleTesis(1,0.5,0.9,100,2000000,100);
        //LargeScaleTesis d500 = new LargeScaleTesis(1,0.5,0.9,100,10000000,500);
        
        //pool.execute(d500);
        
        pool.execute(d100);
        
        do
      {
         System.out.printf("******************************************\n");
         System.out.printf("Main: Parallelism: %d\n", pool.getParallelism());
         System.out.printf("Main: Active Threads: %d\n", pool.getActiveThreadCount());
         System.out.printf("******************************************\n");
         try
         {
            TimeUnit.SECONDS.sleep(1);
         } catch (InterruptedException e)
         {
            e.printStackTrace();
         }
      } while (
                //(!d500.isDone()) || 
                (!d100.isDone()));
        

    }

    public void run() {
        DELOCOS mdde = new DELOCOS(this.F, this.CR, this.NP, this.MaxFes, this.dimension,2);
        mdde.setFunction(new FunctionsSayed(this.func, this.dimension));
        //mdde.setFunction(new SuiteCeC2010(this.func,30));
        mdde.runAlgorithm();
    }

    @Override
    public Object getRawResult() {
        return null;
    }

    @Override
    protected void setRawResult(Object value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected boolean exec() {
        run();
        return true;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.OtherExperiments;

import evoutils.algorithms.DE.CrossOver;
import evoutils.algorithms.DE.Mutations;
import evoutils.algorithms.IBasicAlgorithm;
import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population_antique;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import largescaletesis.experiment.RunResults;

/**
 *
 * @author EkBalam
 */
public class DErand1bin_exp implements IBasicAlgorithm {

    private String name = "DE_rand-1-bin";
    private IFunctionEvaluation function = null;

    private final double F, CR;
    private final int NP;
    private final int MaxFes;
    private final int dimension;
    private final int evalSave;
    //private ArrayList<Solution> pop;
    private Population_antique pop;

    private long time;
    boolean finish = false;

    //Results 
    public RunResults results;
    public LinkedList<Solution> betterSolutions;

    public DErand1bin_exp(double F, double CR, int SN, int MaxFes, int dimension, int evalSave) {
        this.F = F;
        this.CR = CR;
        this.NP = SN;
        this.MaxFes = MaxFes;
        this.dimension = dimension;
        this.evalSave = evalSave;
        //this.pop = new ArrayList<>();
        this.pop = null;
        this.time = 0;
        this.finish = false;
        this.betterSolutions = new LinkedList<>();
        this.results = new RunResults();
    }

    public RunResults run() {
        this.runAlgorithm();
        return this.results;
    }
    
    public RunResults run(Solution[] ipop){
        this.pop = new Population_antique(this.NP);
        for(int i = 0; i<this.NP; i++){
            this.pop.replaceAt(i, ipop[i]);
        }
        this.runAlgorithm();
        return this.results;
    }
    
    public Solution[] getPop(){
        Solution[] returnPop = new Solution[this.NP];
        System.arraycopy(this.pop.getArrayPop(), 0, returnPop, 0, this.NP);
        return returnPop;
    }

    @Override
    public void runAlgorithm() {

        this.time = System.currentTimeMillis();

        int fes = this.NP;
        int fesGlobal = this.NP;
        
        if(this.pop == null){
            this.pop = new Population_antique(this.NP,this.function);
        }else{
            for(int i = 0; i < this.NP; i++){
                this.pop.replaceAt(i, 
                        this.function.evaluate(this.pop.getAt(i)));
            }
        }

        //this.betterSolutions.add(this.pop.getBest().clone());
        //System.out.println("INICIAL: "+this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());

        int ps = 1;
        int c = 0;
        while ((fes < this.MaxFes) && (!finish)) {

            Population_antique popg = new Population_antique(this.NP);
            int i = 0;

            while (i < this.NP && (!finish)) {

                Solution x = this.pop.getAt(i);
                Solution xg = rand1binOp(i);
                fes++;
                fesGlobal++;

                if (x.compareTo(xg) < 0) {
                    popg.replaceAt(i, x);
                } else {
                    popg.replaceAt(i, xg);
                }

                if (fes == this.MaxFes) {
                    finish = true;
                }
                i++;
            }

            if (finish && (i < this.NP)) {
                for (int j = i; j < this.NP; j++) {
                    popg.replaceAt(j, this.pop.getAt(j));
                }
            }
            this.pop = popg;

            //this.betterSolutions.add(this.pop.getBest().clone());

            //this.results.addBestG(this.pop.getBest().getF(), this.pop.getBest().getSvr());
            
            //System.out.println("fINAL: "+this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());
            c++;
           
            if (this.evalSave != 0 && (fes % this.evalSave == 0)) {
                this.exportPop(ps);
                ps++;
            }
        }

        this.time = System.currentTimeMillis() - this.time;

        //this.saveFinalDataExportPop();

        Solution best = this.pop.getBest();

        //System.out.println("Final FES :" + fes + " FES Global = " + fesGlobal + " Final Cycles: " + c);

        //System.out.println(best);
        //System.out.println(time / 1000);
        //this.results.setFinalbestF(best.getF(), best.getSvr());
        //this.results.setGlobalFes(fesGlobal);
    }

    private Solution rand1binOp(int i) {
        int ng = this.function.getNumberIConstraints();
        int nh = this.function.getNumberEConstraints();

        int[] perm = Utils.randperm(this.NP);
        Solution x = this.pop.getAt(i);
        Solution r1 = this.pop.getAt(perm[0]);
        Solution r2 = this.pop.getAt(perm[1]);
        Solution r3 = this.pop.getAt(perm[2]);

        double[] v = Mutations.rand1(this.F, r1.getX(), r2.getX(), r3.getX());
        double[] target = x.getX();
        double[] trial = CrossOver.binomial(target, v, CR);
        trial = Utils.boundaryHandling(trial, function.getLimits());
        Solution r = new Solution(dimension, ng, nh);
        r.setX(trial);
        this.function.evaluate(r);
        return r;
    }

    @Override
    public void setFunction(IFunctionEvaluation function) {
        this.function = function;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public long getTime() {
        return time;
    }

    public void exportPop(int c) {

        ArrayList<double[]> variables = new ArrayList<>();
        for (int i = 0; i < this.dimension; i++) {
            variables.add(new double[this.NP]);
        }

        for (int i = 0; i < this.NP; i++) {
            Solution s = this.pop.getAt(i);
            for (int j = 0; j < this.dimension; j++) {
                variables.get(j)[i] = s.getX()[j];
            }
        }

        try {

            String f = "estatsVariables" + this.function.getFunctionName() + ".m";

            if (c == 1) {
                SaveDataFile.saveString(f, "\nPop" + c + " = [");
            }

            String data = "";

            for (int i = 0; i < variables.size(); i++) {
                double[] v = variables.get(i);
                //double[] stats = Utils.getStatistics(v);

                for (int j = 0; j < v.length; j++) {
                    data = data + v[j] + ",";
                }
                data = data + ";\n";

            }
            //data = data+" ]";
            SaveDataFile.saveString(f, data);
        } catch (IOException ex) {
            Logger.getLogger(DErand1bin_exp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void saveFinalDataExportPop() {
        //SAVE FINAL DATA
        try {
            String f = "estatsVariables" + function.getFunctionName() + ".m";
            SaveDataFile.saveString(f, "];");

            SaveDataFile.saveStringln(f, "limitsU = " + Arrays.toString(function.getLimits()[1]));
            SaveDataFile.saveStringln(f, "limitsL = " + Arrays.toString(function.getLimits()[0]));

            SaveDataFile.saveString(f, "[f c] = size(Pop1);\n"
                    + "d = length(limitsU);\n"
                    + "lu = repmat(limitsU',(f/d),c);\n"
                    + "ll = repmat(limitsL',(f/d),c);\n"
                    + "\n"
                    + "%NORMALIZAR ENTRE UN RANGO VALOR-MINIMO / MAXIMO-MINIMO\n"
                    + "dataNorm = (Pop1 - ll) ./ (lu-ll);\n"
                    + "\n"
                    + "%ESTANDARIZACION VALOR - MEDIA / DESVIACION\n"
                    + "media = mean(Pop1');\n"
                    + "media = repmat(media',1,c);\n"
                    + "\n"
                    + "desv = std(Pop1');\n"
                    + "desv = repmat(desv',1,c);\n"
                    + "PopEstandarizada = (Pop1 - media) ./ desv;\n"
                    + "\n"
                    + "desviaciones = std(dataNorm');\n"
                    + "desviaciones = reshape(desviaciones,d,(f/d));\n"
                    + "\n"
                    + "deviacionesEstandarizadas = std(PopEstandarizada');\n"
                    + "deviacionesEstandarizadas = reshape(deviacionesEstandarizadas,d,(f/d));\n"
                    + "\n"
                    + "plot(desviaciones);\n"
                    + "figure;\n"
                    + "plot(deviacionesEstandarizadas,'--o');");

        } catch (IOException ex) {
            Logger.getLogger(DErand1bin_exp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.OtherExperiments;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2006;
import evoutils.functions.SuiteCeC2010;
import evoutils.utils.SaveDataFile;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] func = { 1 };
        
        //CEC2006
        //int[] func = {1,2,3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24};
        int MaxFes = 200000;
        
        
        //CEC2010 and CLSGO
        //int[] func = {1,2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
        //int MaxFes = 600000;
        //int dimension = 30;
        
        double F = 0.5, CR = 0.9;
        int NP = 100;
        
        int evalSave = 1;

        for (int i = 0; i < func.length; i++) {
            IFunctionEvaluation function = new SuiteCeC2006(func[i]);
            //IFunctionEvaluation function = new SuiteCeC2010(func[i], dimension);
            //IFunctionEvaluation function = new FunctionsSayed(func[i], dimension);
            System.out.println(function.getFunctionName());
            DErand1bin_exp mdde = new DErand1bin_exp(F, CR, NP, MaxFes, function.getDimension(), evalSave);
            mdde.setFunction(function);
            mdde.runAlgorithm();
        }

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.experiment;

import evoutils.utils.ComparatorColumn;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author EkBalam
 */
public class ExperimentRuns {

    private String folderName;
    private String algorithmName;
    private String functionName;
    ArrayList<RunResults> runs = new ArrayList<>();

    public ExperimentRuns(String folderName, String algorithmName, String functionName) {
        this.folderName = folderName;
        
        File  f = new File(this.folderName);
        if(!f.exists()){
            f.mkdirs();
        }
        
        this.algorithmName = algorithmName;
        this.functionName = functionName;
    }
    
    public void setAlgorithmName(String algorithmName){
         this.algorithmName = algorithmName;
    }

    public void addRunResult(RunResults r) {
        this.runs.add(r);
    }

    public void exportData() {

        ArrayList<double[]> feasibleData = new ArrayList<>();
        double[] statistics;
        double[] statFesGlob;
        double[] statFesLocal;
        double[] dataFesGlob = new double[runs.size()];
        double[] dataFesLocal = new double[runs.size()];
        //DATA for fes of viic
        double[] statsViccCfes;
        double[] statsViccFfes;
        double[] dataViicCons = new double[runs.size()];
        double[] dataViicFunc = new double[runs.size()];

        String times = "";
        int i = 0;
        for (RunResults rr : this.runs) {
            if (rr.finalbest[1] == 0) {
                feasibleData.add(new double[]{i, rr.finalbest[0]});
            }
            dataFesGlob[i] = rr.getGlobalFes();
            dataFesLocal[i] = rr.getLocalFes();
            
            dataViicCons[i] = rr.getViicConstraintsFES();
            dataViicFunc[i] = rr.getViicFunctionFES();
            
            times += ""+(rr.getTime()/(double)1000)+";";
            
            i++;
        }
        
        //STATS FES GLOBAL AND LOCAL
        statFesGlob = Utils.getStatistics(dataFesGlob);
        statFesLocal = Utils.getStatistics(dataFesLocal);
        
        //STATS FES VIIC DECOMPOSITION
        statsViccCfes = Utils.getStatistics(dataViicCons);
        statsViccFfes = Utils.getStatistics(dataViicFunc);
        
        int medianI = 0;
        int runsFeasibles = feasibleData.size();

        if (!feasibleData.isEmpty()) {
            feasibleData.sort(new ComparatorColumn(1));
            medianI = runsFeasibles / 2;
            double[] data = new double[runsFeasibles];
            for (int j = 0; j < runsFeasibles; j++) {
                data[j] = feasibleData.get(j)[1];
            }
            medianI = (int) feasibleData.get(medianI)[0];
            statistics = Utils.getStatistics(data);
        } else {
            int size = this.runs.size();
            medianI = size / 2;
            double[] data = new double[size];
            for (int j = 0; j < size; j++) {
                data[j] = this.runs.get(j).finalbest[0];
            }
            //min,median,mean,standard deviation and max in this order
            statistics = Utils.getStatistics(data);
        }
        
        String statT = ";Algorithm;Function;Feasible-runs;best;median;mean;std;worts";
        String stat = this.algorithmName + ";" + functionName + ";" + runsFeasibles + ";" + statistics[0] + ";" + statistics[1] + ";" + statistics[2] + ";" + statistics[3] + ";" + statistics[4];
        
        //STRING STATISTICS OF FES LOCAL AND GLOBAL
        String statFesG = this.algorithmName + ";" + functionName + ";" + runsFeasibles + ";" + statFesGlob[0] + ";" + statFesGlob[1] + ";" + statFesGlob[2] + ";" + statFesGlob[3] + ";" + statFesGlob[4];
        String statFesL = this.algorithmName + ";" + functionName + ";" + runsFeasibles + ";" + statFesLocal[0] + ";" + statFesLocal[1] + ";" + statFesLocal[2] + ";" + statFesLocal[3] + ";" + statFesLocal[4];
        
        //STATITICS OF FES VIIC
        String statViicCFes = "viicCfes;"+this.algorithmName + ";" + functionName + ";" + runsFeasibles + ";" + statsViccCfes[0] + ";" + statsViccCfes[1] + ";" + statsViccCfes[2] + ";" + statsViccCfes[3] + ";" + statsViccCfes[4];
        String statViicFFes = "viicFfes;"+this.algorithmName + ";" + functionName + ";" + runsFeasibles + ";" + statsViccFfes[0] + ";" + statsViccFfes[1] + ";" + statsViccFfes[2] + ";" + statsViccFfes[3] + ";" + statsViccFfes[4];
        
        RunResults medianRun = this.runs.get(medianI);
        String smedianRun = "MedianRun = [";
        String smedianConvergence = "Convergence = [";
        for (i = 0; i < medianRun.bestsf.size(); i++) {
            
            String medianRunvalues = "";
            for(int mi = 0; mi < medianRun.bestsf.get(i).length; mi++){
                medianRunvalues += " "+medianRun.bestsf.get(i)[mi];
            }
            medianRunvalues += ";";
            
            smedianRun = smedianRun + " " + medianRunvalues;
            
            if(!medianRun.convergenceANDnewF.isEmpty())            
                smedianConvergence = smedianConvergence + " " + medianRun.convergenceANDnewF.get(i);
        }
        smedianRun = smedianRun + "]";
        smedianConvergence = smedianConvergence+"];";
        
        String medianX = functionName+"_x ="+Arrays.toString(medianRun.getFinalX());

        String wilcoxonData = "W_" + this.algorithmName + "_" + functionName + " = [";
        if (!feasibleData.isEmpty()) {
            for (int j = 0; j < runsFeasibles; j++) {
                wilcoxonData = wilcoxonData + " " + feasibleData.get(j)[1];
            }
        } else {
            for (RunResults rr : this.runs) {
                wilcoxonData = wilcoxonData + " " + rr.finalbest[0];
            }
        }
        wilcoxonData = wilcoxonData + "];";

        try {
            SaveDataFile.saveString(folderName + algorithmName + "TIME.txt",algorithmName+"_"+functionName+" = "+times + "\n");
            
            SaveDataFile.saveString(folderName + algorithmName + ".txt", "Function " + functionName + "\n");
            SaveDataFile.saveString(folderName + algorithmName + ".txt", statT + "\n");
            SaveDataFile.saveString(folderName + algorithmName + ".txt", stat + "\n");
            SaveDataFile.saveString(folderName + algorithmName + ".txt", smedianRun + "\n");
            SaveDataFile.saveString(folderName + algorithmName + ".txt", wilcoxonData + "\n");
            SaveDataFile.saveString(folderName + algorithmName + ".txt", "Time Median: "+medianRun.getTime()+ "\n");

            SaveDataFile.saveString(folderName + "Estats.txt", stat + "\n");
            SaveDataFile.saveString(folderName + "EstatsFes.txt", statFesG + "\n");
            SaveDataFile.saveString(folderName + "EstatsFes.txt", statFesL + "\n");
            
            //SAVE STATISTICS OF FES VIIC
            SaveDataFile.saveString(folderName + "EstatsVIICFes.txt", statViicFFes + "\n");
            SaveDataFile.saveString(folderName + "EstatsVIICFes.txt", statViicCFes + "\n");
            
            SaveDataFile.saveString(folderName + "Wilcoxon.txt", wilcoxonData + "\n");

            //SAVE DATA FOR MEDIAN RUN 
            //String nameVmedian = this.functionName + algorithmName + "_MedianRun";
            SaveDataFile.saveString(folderName + "ConvergenceMean.m", this.functionName + algorithmName + "_" + smedianRun + ";\n");
            SaveDataFile.saveString(folderName + "ConvergenceMethod.m", this.functionName + algorithmName + "_" + smedianConvergence + ";\n");
            
            //SAVE BEST VECTOR
            SaveDataFile.saveStringln(folderName+"BestX_values.m", medianX);


        } catch (IOException ex) {
            Logger.getLogger(ExperimentRuns.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
}

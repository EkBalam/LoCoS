/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package largescaletesis.experiment;

import java.util.ArrayList;

/**
 *
 * @author EkBalam
 */
public class RunResults {
    
    //Are the best fitness per generation
    ArrayList<double[]> bestsf = new ArrayList<>();   
    
    ArrayList<Double> convergenceANDnewF = new ArrayList<>();
    //final result {fitness, SVC, fes}
    double[] finalbest;
    
    double[] finalX;
            
    double localFes;
    double globalFes;
    double viicConstraintsFES;
    double viicFunctionFES;

    long time;
    
    public RunResults() {
        bestsf = new ArrayList<>();
    }
    
    public void setConvergenceANDnewF(double convergence) {
        this.convergenceANDnewF.add(convergence);
    }
    
    public void addBestG(double bestf, double svc){
        if(svc > 0){
            bestf = Double.NaN;
            svc = Double.NaN;
        }
        double[] b = {bestf,svc};
        this.bestsf.add(b);
    }    
    
    public void addBestG(double bestf, double svc, int fes){
        double[] b = {bestf,svc, fes};
        this.bestsf.add(b);
    }    
    
    public ArrayList<double[]> getBests() {
         return bestsf;
    }

    public double[] getFinalX() {
        return finalX;
    }

    public void setFinalX(double[] finalX) {
        this.finalX = finalX;
    }

    public double[] getFinalbestF() {
        return finalbest;
    }

    public void setFinalbestF(double finalbestF,double svc) {
        this.finalbest = new double[]{finalbestF,svc};
    }

    public void setViiCconstraintsFes(double viicCFES ){
        this.viicConstraintsFES = viicCFES;
    }
    
    public void setViiCfunctionFes(double viicFFES ){
        this.viicFunctionFES = viicFFES;
    }

    public double getViicConstraintsFES() {
        return viicConstraintsFES;
    }

    public double getViicFunctionFES() {
        return viicFunctionFES;
    }
        
    public double getLocalFes() {
        return localFes;
    }

    public void setLocalFes(double localFes) {
        this.localFes = localFes;
    }

    public double getGlobalFes() {
        return globalFes;
    }

    public void setGlobalFes(double globalFes) {
        this.globalFes = globalFes;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
       
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import java.io.IOException;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author Adan
 */
public class ComputeT1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int[] dimensions = {100, 500, 1000};

        for (int d = 0; d < dimensions.length; d++) {
            int[] function = {1, 2, 3, 4, 5, 6};

            for (int i = 0; i < function.length; i++) {
                IFunctionEvaluation f = new FunctionsSayed(function[i], dimensions[d]);
                int ng = f.getNumberIConstraints();
                int nh = f.getNumberEConstraints();
                int dimension = f.getDimension();
                

                long ti = System.currentTimeMillis();
                for (int j = 0; j < 200000; j++) {
                    double[] x = Utils.generateVectorRandom(dimension, f.getLimits());
                    Solution sn = new Solution(dimension, ng, nh);
                    sn.setX(x);
                    f.evaluate(sn);
                }
                long t = System.currentTimeMillis() - ti;
                System.out.println(t / 1000.0);
                SaveDataFile.saveStringln("./TimeExperiment/TIME1_2.txt","F"+(i+1)+"_"+dimensions[d]+" = "+(t / 1000.0));
            }
        }

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2010_LS;
import java.util.Arrays;
import largescaletesis.algorithm.DELOCOS;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

/**
 * NOTE: only work with Emman benchmark
 * 
 * @author Adan
 */
public class ExperimentFunction {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Options options = new Options();

        Option f_value = new Option("F", "F", true, "F");
        f_value.setRequired(true);
        options.addOption(f_value);

        Option cr_value = new Option("CR", "CR", true, "CR");
        cr_value.setRequired(true);
        options.addOption(cr_value);
        
        Option np_value = new Option("NP", "NP", true, "NP");
        np_value.setRequired(true);
        options.addOption(np_value);
        
        Option d_value = new Option("D", "Dimension", true, "D");
        d_value.setRequired(true);
        options.addOption(d_value);
        
        Option funct_value = new Option("Funct", "Function", true, "Function");
        funct_value.setRequired(true);
        options.addOption(funct_value);
        
        Option alg_value = new Option("alg", "algortihm", true, "Algortihm DELOCOS, DELODES");
        alg_value.setRequired(false);
        options.addOption(alg_value);
        
              
//        Option alg_value = new Option("Alg", "algorithm", true, "algorithm");
//        alg_value.setRequired(true);
//        options.addOption(alg_value);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
            return;
        }

        double F = Double.valueOf(cmd.getOptionValue("F"));
        double CR = Double.valueOf(cmd.getOptionValue("CR"));
        int    NP = Integer.valueOf(cmd.getOptionValue("NP"));
        int    function = Integer.valueOf(cmd.getOptionValue("Funct"));
        int    dimension = Integer.valueOf(cmd.getOptionValue("D"));
        String algorithm = cmd.getOptionValue("alg", "DELOCOS");
        int m = 2;
        int MaxFes = 20000*dimension;
        int runs = 25;
        
        System.out.println(algorithm);
        String folder = "./DELOCOS_Irace/Expd1000/";
        
        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        //IFunctionEvaluation f = new SuiteCeC2010_LS(function,dimension);
        ExperimentRuns er4 = new ExperimentRuns(folder, "AlgorithmName", f.getFunctionName());
        for (int e = 0; e < runs; e++) {
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e);

            DELOCOS mdde4 = new DELOCOS(F, CR, NP, MaxFes, dimension, m);
            er4.setAlgorithmName(mdde4.getName());

            mdde4.setFunction(f);

            RunResults r4 = mdde4.run();
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
            System.out.println(Arrays.toString(r4.getFinalbestF()));
            er4.addRunResult(r4);
        }
        er4.exportData();
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.functions.constrained;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;

/**
 *
 * @author EkBalam
 */
public class FunctionsSayed implements IFunctionEvaluation {

    private final int function;
    private final int dimension;

    public FunctionsSayed(int function, int dimension) {
        this.function = function;
        this.dimension = dimension;
    }

    @Override
    public Solution evaluate(Solution solution) {
        double[] res = Benchmark18.eval(function, solution.getX());

        solution.setF(res[0]);

        double[] constraints = new double[res.length - 1];

        for (int i = 1; i < res.length; i++) {
            constraints[i - 1] = res[i];
        }

        solution.updateSolution(res[0], solution.getX(), constraints, solution.getH());

        return solution;
    }

    /**
     * 
     * @return a vector with the limits per variable [limit][variable]
     * limit = 0 lower limit
     * limit = 1 upper limit
     */
    @Override
    public double[][] getLimits() {
        double[][] l = new double[2][dimension];

        for (int i = 0; i < dimension; i++) {
            l[0][i] = 0;
        }
        for (int i = 0; i < dimension; i++) {
            l[1][i] = 100;
        }
        
        return l;
    }

    @Override
    public int getNumberEConstraints() {
        return 0;
    }

    @Override
    public int getNumberIConstraints() {
        int nr = this.function % 3;
        nr = nr == 0 ? 3 : nr;
        return nr;
    }

    @Override
    public int[] getNumberConstraints() {
        int nr = this.function % 3;
        nr = nr == 0 ? 3 : nr;
        int r[] = new int[2];
        r[0] = nr;
        r[1] = 0;

        return r;
    }

    @Override
    public int getDimension() {
        return dimension;
    }

    @Override
    public String getFunctionName() {
        String format = "F%02d";
        return String.format(format, this.function);
    }

    @Override
    public double getOptimalValueKnown() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getFunction(){
        return this.function;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.functions.constrained;

import evoutils.utils.VectorOperations;
import java.util.Arrays;

/**
 *
 * @author EkBalam
 */
public class BasicFunctionsSayed {

    public static double obj1(double[] x) {
        double rest = 0;
        int length = x.length;

        for (int i = 0; i < length; i++) {
            rest += (x[i] * x[i]);
        }

        return rest;
    }

    public static double obj2(double[] x) {
        double rest = 0;
        int length = 5;
        double N = x.length;
        double gamma = 0.10;
        double COUNTS = (gamma * N) / length;

        double i, j, count, n1, n2, n3, l;

        for (count = 0; count < COUNTS; count++) {

            n1 = (count * length / gamma) + length;
            double sum1 = 0;

            for (i = ((N / COUNTS) * (count)); i < n1; i++) {
                //System.out.print(i + ", ");
                sum1 += x[(int) i] * x[(int) i];
            }
            //System.out.println();

            n2 = (count * length / gamma) + (1 / gamma);
            double sum2 = 0;
            for (j = n1; j < n2 - 1; j++) {
                //System.out.print(j + ", ");
                double p1 = 100 * Math.pow((x[(int) j] * x[(int) j])
                        - x[(int) j + 1],
                        2);
                double p2 = Math.pow((x[(int) j] - 1), 2);
                sum2 += p1 + p2;

            }
            //System.out.println();

            //n3 = (count + 1) * (length / gamma);
            n3 = (N / COUNTS) * (count + 1);
            double sum3 = 0;

            for (l = n2; l < n3; l++) {
                //System.out.print(l + ", ");
                sum3 += x[(int) l] * x[(int) l];
            }
            //System.out.println();

            rest += (sum1 + sum2 + sum3);

        }

        return rest;
    }

    public static double obj3(double[] x) {
        double rest = 0;
        int length = 5;
        double N = x.length;
        double gamma = 0.10;
        double COUNTS = (gamma * N) / (2 * length);
        double i, j, count, n1, n2;

        for (count = 0; count < COUNTS; count++) {

            n1 = (2 * count * length / gamma) + length;
            double sum1 = 0;
            for (i = (2 * count * length / gamma); i < n1; i++) {
                //System.out.println(i+" "+(i + (length / gamma)));
                double p0 = (x[(int) i] * x[(int) i]) - x[(int) (i + (length / gamma))];
                double p1 = (100 * Math.pow(p0, 2)) + Math.pow(x[(int) i] - 1, 2);
                sum1 += (p1);
            }
            //System.out.println("--");
            
            n2 = (2 * count * length / gamma) + (length / gamma);
            double sum2 = 0;
            
            for (j = n1; j < n2; j++) {
                //System.out.println((j)+" "+(j+50));
                sum2 += (Math.pow(x[(int) j], 2) + Math.pow(x[(int) (j + (length / gamma))], 2));
            }
            //System.out.println();
            rest += (sum1 + sum2);
        }

        return rest;
    }

    public static double obj4(double[] x) {
        double res = 0;
        
        int n = x.length;
        int beg = 0; 
        int en = (int) (0.05*n+0.02*n);
        
        for(int i = beg; i<(en-1); i++){
            res += 100*Math.pow(Math.pow(x[i], 2)-x[i+1], 2)+Math.pow(x[i]-1, 2);
        }
        
        beg = (int) (0.05*n); en = (int) (0.10*n);
        for(int i = beg; i<(en-1); i++){
            res += 100*Math.pow(Math.pow(x[i], 2)-x[i+1], 2)+Math.pow(x[i]-1, 2);
        }
        
        beg=(int) (0.10*n); en = (int) (0.6*n);
        for(int j = beg; j < en; j++){
            res += Math.pow(x[j], 2);
        }    
        
        //OVERLAPPING
        beg=(int) (0.6*n); en = (int) (0.65*n+0.02*n);
        for(int i = beg; i<(en-1); i++){
            res += 100*Math.pow(Math.pow(x[i], 2)-x[i+1], 2)+Math.pow(x[i]-1, 2);
        }       
        
        beg=(int) (0.65*n); en = (int) (0.7*n);
        for(int i = beg; i<(en-1); i++){
            res += 100*Math.pow(Math.pow(x[i], 2)-x[i+1], 2)+Math.pow(x[i]-1, 2);
        }
        
        beg=(int) (0.7*n); en = n;
        for(int j = beg; j < en; j++){
            res += Math.pow(x[j], 2);
        } 
        
        return res;
    }

    public static double obj5(double[] x) {
        double res = 0;
        
        int beg = 0; 
        int end = (int)(0.10*x.length/2);
        
        double sum = 0;
        
        for(int j = beg; j < end-1; j++){
            //System.out.println(j+" "+(2*j)+" "+(2*j+2)+" "+((2*j)+1));
            sum += 100 * Math.pow(Math.pow(x[2*j], 2)-x[2*j+2],2)+Math.pow(x[2*j]-1, 2);
            sum += 100 * Math.pow(Math.pow(x[(2*j)+1], 2)-x[(2*j)+1+2],2)+Math.pow(x[(2*j)+1]-1, 2);
            
        }
        
        for(int j = 0; j < 0.02*x.length; j++){
            //System.out.println(j+"");
            sum += 100*Math.pow(Math.pow(x[j], 2)-x[j+1],2)+ Math.pow(x[j]-1, 2); 
        }
        
        int b = (int)(0.10*x.length); int e = (int)(0.6*x.length);
        //System.out.println(b+" "+e);
        for(int j = b; j < e; j++){
            sum += Math.pow(x[j], 2);
        }    
        
        double [] y = Arrays.copyOfRange(x,(int)(0.6*x.length),(int)((0.7*x.length)));
        end = y.length/2;
        for(int j = beg; j < end-1; j++){
            //System.out.println(j+" "+(2*j)+" "+(2*j+2)+" "+((2*j)+1));
            sum += 100 * Math.pow(Math.pow(y[2*j], 2)-y[2*j+2],2)+Math.pow(y[2*j]-1, 2);
            sum += 100 * Math.pow(Math.pow(y[(2*j)+1], 2)-y[(2*j)+1+2],2)+Math.pow(y[(2*j)+1]-1, 2);
            
        }  
        
        for(int j = 0; j < 0.02*x.length; j++){
            sum += 100 * Math.pow(Math.pow(y[j], 2)-y[j+1],2)+Math.pow(y[j]-1, 2);
        }  
        
        b = (int)(0.70*x.length); e = x.length;
        y = Arrays.copyOfRange(x,b,e);
        sum += VectorOperations.sum(VectorOperations.pow(y,2));
                
        res = sum;
        return res;
    }

    public static double obj6(double[] x) {
        double res  = 0;
        int n = x.length;
        int ov_size = (int) (n/(0.1*n));
        for(int j = 0; j < n/2-1; j++){
            res += 100* Math.pow(Math.pow(x[2*j], 2)-x[2*j+2],2)+Math.pow(x[2*j]-1,2);
            res += 100* Math.pow(Math.pow(x[2*j+1],2)-x[2*j+1+2],2)+Math.pow(x[2*j+1]-1, 2);
        }
        //System.out.println(ov_size);
        for(int N = 0; N < n/10; N++){
            for(int j = 0; j < 1; j++){
                res += 100*Math.pow(Math.pow(x[2*j+(N)*ov_size], 2)-x[2*j+(N)*ov_size+1], 2) + Math.pow(x[2*j+(N)*ov_size]-1, 2);
            }
        }
        
        return res;
    }

    public static double g01(double[] x) {
        double N = x.length;
        double n1 = 0.01 * N;
        double length = 5;

        double sum = 0;
        for (int i = 0; i < n1; i++) {
            double fi = 25 + (i * 100);
            //System.out.print("[ ");
            for (int j = 0; j < length; j++) {
                // System.out.print( j + fi +" ");
                sum += Math.pow(x[(int) (j + fi)], 2);
            }
            //System.out.print(" ] , ");
        }

        return sum;
    }

    public static double g02(double[] x) {
        double N = x.length;
        double length = 3;
        double fi;

        int l = 1;
        if (N == 100) {
            l = 1;
        } else if (N == 500) {
            l = 2;
        } else if (N == 1000) {
            l = 3;
        }

        double sum = 0;
        for (int i = 0; i < l; i++) {
            fi = (50) + ((i) * 400);
            //System.out.print("[ ");
            for (int j = 0; j < length - 1; j++) {
                //System.out.print( (j + fi) +" " + (j+fi+1) + " ");
                double p0 = Math.pow(x[(int) (j + fi)], 2) - x[(int) (j + fi + 1)];
                double p1 = 100 * Math.pow(p0, 2) + Math.pow(x[(int) (j + fi)] - 1, 2);
                sum += p1;
            }
            //System.out.print(" ] , ");
        }

        return sum;
    }

    public static double g03(double[] x) {
        double N = x.length;
        double sum = 0;
        int l = 1;
        if (N == 100) {
            l = 1;
        } else if (N == 500) {
            l = 2;
        } else if (N == 1000) {
            l = 3;
        }
        //System.out.print("[ ");

        //menos 1 por que mis indices empiezan en 0...
        double fi1base = 9;
        double fi2base = (89 + (l - 1) * 400);

        for (int i = 0; i < l; i++) {
            double inc = (i) * 6;
            double fi1 = fi1base + inc;
            double fi2 = fi2base + inc;

            //System.out.print(fi1+" "+fi2+" ");
            double p0 = Math.pow(x[(int) (fi1)], 2) - x[(int) (fi2)];
            double p1 = 100 * Math.pow(p0, 2) + Math.pow(x[(int) (fi1)] - 1, 2);

            sum += p1;
        }
        //System.out.print(" ], ");
        return sum;

    }

}

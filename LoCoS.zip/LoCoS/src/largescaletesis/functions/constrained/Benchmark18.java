/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.functions.constrained;

/**
 *
 * @author EkBalam
 */
public class Benchmark18 {

    public static double[] eval(int function, double[] x) {
        double fit;
        double evaluation [];
        switch (function) {
            case 1: case 2: case 3:
                fit = BasicFunctionsSayed.obj1(x);
                break;
            case 4:case 5:case 6:
                fit = BasicFunctionsSayed.obj2(x);
                break;
            
            case 7:case 8:case 9:
                fit = BasicFunctionsSayed.obj3(x);
                break;
                
            case 10:case 11:case 12:
                fit = BasicFunctionsSayed.obj4(x);
                break;
                
            case 13:case 14:case 15:
                fit = BasicFunctionsSayed.obj5(x);
                break;
                
            case 16:case 17:case 18:
                fit = BasicFunctionsSayed.obj6(x);
                break;
            default: return null;
        }
        
        evaluation = evalConstraints(function,x,fit);
        
        return evaluation;
    }

    

    private static double[] evalConstraints(int function, double[] x, double fit) {

        int nr = function % 3;
        nr = nr == 0 ? 3 : nr;

        double[] r = new double[nr+1];
        
        r[0] = fit;
        r[1] = BasicFunctionsSayed.g01(x);
        
        if(nr >= 2)
            r[2] = BasicFunctionsSayed.g02(x);
        if(nr == 3){
            r[2] = BasicFunctionsSayed.g02(x);
            r[3] = BasicFunctionsSayed.g03(x);
        }

        return r;
    }

}

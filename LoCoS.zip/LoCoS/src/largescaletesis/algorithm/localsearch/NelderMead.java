/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2006;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population;
import evoutils.utils.Utils;
import evoutils.utils.VectorOperations;
import java.util.Arrays;

/**
 * Basado en las notas del Dr. Coello
 * http://delta.cs.cinvestav.mx/~ccoello/optimizacion/clase11-opt-2005.pdf.gz
 *
 *
 * N+(3*maxCycles) evals
 *
 * @author EkBalam
 */
public class NelderMead {

    private double alpha;
    private double beta;
    private double gamma;
    private double epsilon;

    private IFunctionEvaluation function;

    private int max_Cycles;
    private int max_LocalFes;
    private int maxFes;

    /**
     *
     * @param alpha
     * @param beta
     * @param gamma
     * @param epsilon
     */
    public NelderMead(double alpha, double beta, double gamma, double epsilon) {
        this.alpha = alpha;
        this.beta = beta;
        this.gamma = gamma;
        this.epsilon = epsilon;
        this.max_Cycles = Integer.MAX_VALUE;
        this.max_LocalFes = 1000;
        this.maxFes = this.max_Cycles;
    }

    /**
     *
     * @param alpha
     * @param beta
     * @param gamma
     * @param epsilon
     * @param function
     */
    public NelderMead(double alpha, double beta, double gamma, double epsilon, IFunctionEvaluation function) {
        this.alpha = alpha;
        this.beta = beta;
        this.gamma = gamma;
        this.epsilon = epsilon;
        this.function = function;
        this.max_Cycles = Integer.MAX_VALUE;
        this.max_LocalFes = 1000;
        this.maxFes = this.max_Cycles;
    }

    public NelderMead(double alpha, double beta, double gamma, double epsilon, IFunctionEvaluation function, 
            int max_Cycles, int maxFES) {
        this.alpha = alpha;
        this.beta = beta;
        this.gamma = gamma;
        this.epsilon = epsilon;
        this.function = function;
        this.max_Cycles = max_Cycles;
        this.max_LocalFes = 1000;
        this.maxFes = maxFES;
    }
    
    public NelderMead(double alpha, double beta, double gamma, double epsilon, IFunctionEvaluation function, 
            int max_Cycles, int max_LocalFes, int maxFES) {
        this.alpha = alpha;
        this.beta = beta;
        this.gamma = gamma;
        this.epsilon = epsilon;
        this.function = function;
        this.max_Cycles = max_Cycles;
        this.max_LocalFes = max_LocalFes;
        this.maxFes = maxFES;
    }

    /**
     *
     * @param s
     * @param variables
     * @param currentFes
     * @return
     */
    public LocalSearchResult localSearch(Solution s, int[] variables, int currentFes) {
        LocalSearchResult lsr = new LocalSearchResult();
        
        int N = variables.length;

        int evals = 0;
        //SIMPLEX CREATION
        double delta1 = ((Math.pow(N + 1, 0.5) + (N - 1)) / (N * Math.sqrt(2))) * this.alpha;
        double delta2 = ((Math.pow(N + 1, 0.5) - 1) / (N * Math.sqrt(2))) * this.alpha;

        Population simplex = new Population(N + 1);
        simplex.replaceAt(N, s.clone());

        int ng = function.getNumberIConstraints();
        int nh = function.getNumberEConstraints();
        int dimension = function.getDimension();

        for (int i = 0; i < N; i++) {
            double xn[] = Arrays.copyOf(s.getX(), dimension);
            for (int j = 0; j < N; j++) {
                if (i == j) {
                    xn[variables[j]] = s.getX()[variables[j]] + delta1;
                } else {
                    xn[variables[j]] = s.getX()[variables[j]] + delta2;
                }
            }
            Solution ns = new Solution(dimension, ng, nh);
            ns.setX(xn);
            this.function.evaluate(ns);
            evals++;
            simplex.replaceAt(i, ns);
        }
        //END SIMPLEX CREATION

        //System.out.println(simplex);     
        //simplex.sort();
        //System.out.println("\n ORDENADO \n");
        //System.out.println(simplex);
        double Q = this.epsilon + 1;

        int countCycles = 0;
        boolean endCycle = false;

        while (Q > this.epsilon && !endCycle && countCycles < this.max_Cycles
                //while (countCycles < this.max_Cycles
                //&& (evals < this.max_LocalFes) 
                && (evals + currentFes < this.maxFes)) {
            simplex.sort();
            //System.out.println(simplex);
            
            //Index for Best, Worst and Second Worts
            int best = 0;
            int worst = N;
            int sWorst = N - 1;
            
            lsr.addConvergenceValue(simplex.getAt(best).clone());
            
            //Centroid and Evaluate
            double xc[] = Utils.centroid(Arrays.copyOfRange(simplex.getArrayPop(), 0, N));
            Solution scentroide = new Solution(dimension, ng, nh);
            scentroide.setX(xc);
            this.function.evaluate(scentroide);
            evals++;

            //Worts
            double xh[] = simplex.getAt(N).getX();

            double end = VectorOperations.sum(VectorOperations.rest(xc, xh));
            //System.out.println("-- "+end);
            endCycle = Math.abs(end) <= this.epsilon;

            //Reflex point and Evaluate
            double xr[] = this.reflexPoint(s.getX(), xc, xh, variables);
            Solution sr = new Solution(dimension, ng, nh);
            sr.setX(xr);
            this.function.evaluate(sr);
            evals++;

            double xnew[] = Arrays.copyOf(xr, dimension);

            if (sr.compareTo(simplex.getAt(best)) < 0) {
                xnew = this.expansionPoint(s.getX(), xc, xh, variables);
            } else if (sr.compareTo(simplex.getAt(worst)) >= 0) {
                xnew = this.contractionPoint(s.getX(), xc, xh, variables);
            } else if (sr.compareTo(simplex.getAt(sWorst)) > 0) {
                xnew = this.contractionPoint2(s.getX(), xc, xh, variables);
            }/* else {
             System.out.println("Ninguna de las anteriores");
             }*/

            xnew = Utils.boundaryHandling(xnew, this.function.getLimits());

            //Xnew Evaluation
            Solution snew = new Solution(dimension, ng, nh);
            snew.setX(xnew);
            this.function.evaluate(snew);
            evals++;
            //Repleacement of worst by xnew
            simplex.replaceAt(N, snew);

            Q = this.calculateQ(simplex, scentroide);
            //Q = calculateDistanceToCentroid(simplex);
            countCycles++;

            //System.out.println("Distancia al cenntroide = "+calculateDistanceToCentroid(simplex)+" Q= "+Q);
        }

        //System.out.println("Numero de mejoras = "+countImproves+" Cycles = "+countCycles);
        simplex.sort();

       
        lsr.result = simplex.getAt(0);
        lsr.addConvergenceValue(simplex.getAt(0).clone());
        lsr.finish = false;

        lsr.FEs = evals;

        return lsr;
    }

    private double calculateQ(Population simplex, Solution scentroide) {
        double sum = 0.0;

        int N = simplex.getNp();

        for (int i = 0; i < N; i++) {
            sum += (simplex.getAt(i).getF() - scentroide.getF());
        }

        return Math.sqrt(Math.pow(sum, 2) / N);

    }

    private double calculateDistanceToCentroid(Population simplex) {
        double sum = 0.0;

        double xc[] = Utils.centroid(simplex.getArrayPop());

        int N = simplex.getNp();

        for (int i = 0; i < N; i++) {
            sum += (VectorOperations.euclidianDistance(simplex.getAt(i).getX(), xc));
        }

        return sum / N;
    }

    private double[] reflexPoint(double[] origen, double[] centroid, double[] worst, int[] variables) {
        double[] xr = Arrays.copyOf(origen, origen.length);

        for (int i = 0; i < variables.length; i++) {
            //xr[variables[i]] = (NelderMead.phi * centroid[variables[i]]) - worst[variables[i]];
            xr[variables[i]] = (2 * centroid[variables[i]]) - worst[variables[i]];
        }

        return xr;
    }

    private double[] expansionPoint(double[] origen, double[] centroid, double[] worst, int[] variables) {
        double[] xe = Arrays.copyOf(origen, origen.length);

        for (int i = 0; i < variables.length; i++) {
            xe[variables[i]] = ((1 + this.gamma) * centroid[variables[i]]) - (this.gamma * worst[variables[i]]);
        }

        return xe;
    }

    private double[] contractionPoint(double[] origen, double[] centroid, double[] worst, int[] variables) {
        double[] xcontraction = Arrays.copyOf(origen, origen.length);

        for (int i = 0; i < variables.length; i++) {
            xcontraction[variables[i]] = ((1 - this.beta) * centroid[variables[i]]) + (this.beta * worst[variables[i]]);
        }

        return xcontraction;
    }

    private double[] contractionPoint2(double[] origen, double[] centroid, double[] worst, int[] variables) {
        double[] xcontraction2 = Arrays.copyOf(origen, origen.length);

        for (int i = 0; i < variables.length; i++) {
            xcontraction2[variables[i]] = ((1 + this.beta) * centroid[variables[i]]) - (this.beta * worst[variables[i]]);
        }

        return xcontraction2;
    }

    public double getAlpha() {
        return alpha;
    }

    public void setAlpha(double alpha) {
        this.alpha = alpha;
    }

    public double getBeta() {
        return beta;
    }

    public void setBeta(double beta) {
        this.beta = beta;
    }

    public double getGamma() {
        return gamma;
    }

    public void setGamma(double gamma) {
        this.gamma = gamma;
    }

    public double getEpsilon() {
        return epsilon;
    }

    public void setEpsilon(double epsilon) {
        this.epsilon = epsilon;
    }

    public IFunctionEvaluation getFunction() {
        return function;
    }

    public void setFunction(IFunctionEvaluation function) {
        this.function = function;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IFunctionEvaluation f = new SuiteCeC2006(11);
        //f.dimension = 2;

        Solution s = new Solution(f.getDimension(), f.getNumberIConstraints(), f.getNumberEConstraints());
        double v[] = {0.4, 0.4};
        s.setX(v);
        f.evaluate(s);
        System.out.println(s);

        NelderMead ls = new NelderMead(1, 0.5, 1.5, 0.0001, f);

        int variables[] = {0, 1};
        LocalSearchResult lsr = ls.localSearch(s, variables, 0);

        System.out.println(lsr.result);
        System.out.println(lsr.FEs);

    }

}

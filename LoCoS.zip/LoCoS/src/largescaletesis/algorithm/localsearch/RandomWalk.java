/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2006;
import evoutils.solutions.Solution;
import evoutils.utils.Utils;
import evoutils.utils.VectorOperations;
import java.util.Arrays;

/**
 *
 * @author EkBalam
 */
public class RandomWalk {

    private double lamda;
    private int max_Cycles;
    private double epsilon;

    private IFunctionEvaluation function;

    private int max_LocalFes;
    private int maxFes;

    public RandomWalk(double lamda, int max_Cycles, double epsilon, IFunctionEvaluation function, int max_LocalFes, int maxFes) {
        this.lamda = lamda;
        this.max_Cycles = max_Cycles;
        this.epsilon = epsilon;
        this.function = function;
        this.max_LocalFes = max_LocalFes;
        this.maxFes = maxFes;
    }

    public RandomWalk(double lamda, int max_Cycles, double epsilon, IFunctionEvaluation function, int maxFes) {
        this.lamda = lamda;
        this.max_Cycles = max_Cycles;
        this.epsilon = epsilon;
        this.function = function;
        this.max_LocalFes = 1000;
        this.maxFes = maxFes;
    }

    public void setFunction(IFunctionEvaluation ife) {
        this.function = ife;
    }

    /**
     *
     * @param s
     * @param variables
     * @param currentFes
     * @return
     */
    public LocalSearchResult localSearch(Solution s, int[] variables, int currentFes) {
        LocalSearchResult lsr = new LocalSearchResult();

        double L = this.lamda;
        int evals = 0;
        Solution s1 = s.clone();
        Solution sn;

        while (L > this.epsilon
                //&& (evals < this.max_LocalFes) 
                && (evals + currentFes < this.maxFes)) {
            lsr.addConvergenceValue(s1.clone());

            int i = 0;
            while (i < this.max_Cycles) {
                sn = s1.clone();
                double[] nx = this.xnew(s1.getX(), variables, L);
                nx = Utils.boundaryHandling(nx, this.function.getLimits());
                sn.setX(nx);

                sn = function.evaluate(sn);
                evals++;

                if (sn.compareTo(s1) < 0) {
                    s1 = sn;
                } else {
                    i++;
                }
            }

            L = L / 2;

        }

        lsr.result = s1;
        lsr.finish = false;
        lsr.addConvergenceValue(s1.clone());
        lsr.FEs = evals;

        return lsr;
    }

    public double[] xnew(double[] x, int[] variables, double L) {

        double[] lamdaU = VectorOperations.mult(this.unitVector(variables.length), L);
        double[] xn = Arrays.copyOf(x, x.length);

        //System.out.println("LamdaU = "+Arrays.toString(lamdaU));
        for (int i = 0; i < variables.length; i++) {
            int var = variables[i];
            xn[var] = xn[var] + lamdaU[i];
        }
        return xn;
    }

    public double[] unitVector(int dimension) {
        double[] r = new double[dimension];
        double[] r2;
        double r3 = 0;
        boolean found = false;
        while (!found) {
            r = Utils.generateVectorRandom(dimension, 1, -1);
            r2 = VectorOperations.pow(VectorOperations.pow(r, 2), 1.0 / 2.0);
            r3 = 1 / VectorOperations.sum(r2);
            if (r3 <= 1) {
                found = true;
            }
            //System.out.println("Ciclo");
        }
        double[] u = VectorOperations.mult(r, r3);

        return u;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IFunctionEvaluation f = new SuiteCeC2006(11);
        Solution s = new Solution(f.getDimension(), f.getNumberIConstraints(), f.getNumberEConstraints());
        double[] v = {0.4, 0.4};
        s.setX(v);
        f.evaluate(s);
        System.out.println(s);

        //System.out.println(Arrays.toString(f.getLimits()[0]));
        RandomWalk rw = new RandomWalk(1, 10, 0.0001, f, Integer.MAX_VALUE, Integer.MAX_VALUE);
        int variables[] = {0, 1};
        LocalSearchResult lsr = rw.localSearch(s, variables, 0);

        System.out.println(lsr.result);
        System.out.println(lsr.FEs);
    }

}

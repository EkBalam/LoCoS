/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;


/**
 *
 * @author adam
 */
public class Himmelblau implements IFunctionEvaluation{


    @Override
    public Solution evaluate(Solution solution) {
        double fit = Math.pow((Math.pow(solution.getX()[0],2)+solution.getX()[1]-11),2)+Math.pow((solution.getX()[0]+Math.pow(solution.getX()[1], 2)-7), 2);
               
        solution.updateSolution(fit, solution.getX(), solution.getG(), solution.getH());
        
        return solution;
    }

    @Override
    public double[][] getLimits() {
        double[][] ll = {{0.0,0.0},{100.0,100.0}};
        return ll;
    }

    @Override
    public int[] getNumberConstraints() {
        int r[] = {0,0};
        return r;
    }

    @Override
    public int getDimension() {
        return 2;
    }

    @Override
    public String getFunctionName() {
        return "";
    }

    @Override
    public int getNumberEConstraints() {
        return 0;
    }

    @Override
    public int getNumberIConstraints() {
       return 0;
    }

    @Override
    public double getOptimalValueKnown() {
        return 0.0;
    }
    
}

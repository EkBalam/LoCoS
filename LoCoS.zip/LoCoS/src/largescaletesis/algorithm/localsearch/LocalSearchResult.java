/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package largescaletesis.algorithm.localsearch;

import evoutils.solutions.Solution;
import java.util.ArrayList;

/**
 *
 * @author EkBalam
 */
public class LocalSearchResult {
    public Solution result;
    public int FEs = 0;
    public boolean finish = false;
    public ArrayList<Solution> convergence;
    
    public LocalSearchResult(){
        convergence = new ArrayList<>();
    }
    
    public void addConvergenceValue(Solution s){
       // this.convergence.add(s);
    }
    
}

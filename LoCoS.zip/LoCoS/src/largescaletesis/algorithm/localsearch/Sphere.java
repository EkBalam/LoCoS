/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.utils.VectorOperations;

/**
 *
 * @author EkBalam
 */
public class Sphere implements IFunctionEvaluation{

    public int dimension = 2;
    
    @Override
    public Solution evaluate(Solution solution) {
        double fit = 0.0;
        
        fit = VectorOperations.sum(VectorOperations.pow(solution.getX(),2));
         
        solution.updateSolution(fit, solution.getX(), solution.getG(), solution.getH());
        
        return solution;
    }

    @Override
    public double[][] getLimits() {
        double[][] ll = new double[2][this.dimension];
        
        for(int i = 0; i < this.dimension ; i++){
            ll[0][i] = 0;
            ll[1][i] = 100;
        }
        
        return ll;
    }

    @Override
    public int[] getNumberConstraints() {
        int r[] = {0,0};
        return r;
    }

    @Override
    public int getDimension() {
        return this.dimension;
    }

    @Override
    public String getFunctionName() {
        return "Sphere";
    }

    @Override
    public int getNumberEConstraints() {
        return 0;
    }

    @Override
    public int getNumberIConstraints() {
       return 0;
    }

    @Override
    public double getOptimalValueKnown() {
        return 0.0;
    }
    
}

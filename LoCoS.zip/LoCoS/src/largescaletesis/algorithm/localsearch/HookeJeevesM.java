package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2006;
import evoutils.solutions.Solution;
import evoutils.utils.Utils;
import evoutils.utils.VectorOperations;

/**
 *
 * @author adam
 *
 * 3.- El valor de epsilon se calcula de la norma de delta entre la dimension
 * por la el maximo de evaluaciones permitidas 4.- eps y base eliminados del
 * constructor, dado que eps se calcula respecto al vector de incrementos base y
 * la base se solicita cada vez que se pide ejecutar el algoritmo.
 *
 * Problema: Cuando el vector DELTA tiene desviacion estandar 0.0 entra en el
 * buscador local pero no hace nada ya que no tiene valor de paso.
 */
public class HookeJeevesM {

    double alpha;
    double eps = 0.0001;
    IFunctionEvaluation function;
    int[] variables;

    int MaxFes;

    long successMoves = 0;
    long improvementMoves = 0;
    int countEvs = 0;
    int Initial_cyclesMax = 2;
    double base = 0.5;
    private double[] delta;

    /**
     *
     * @param alpha factor de decremento
     * @param MaxFes Maximo de evaluaciones permitidas para el algoritmo
     * @param function Funcion objetivo a evaluar
     */
    public HookeJeevesM(double alpha, int MaxFes, IFunctionEvaluation function) {
        this.alpha = alpha;
        this.function = function;
        this.countEvs = 0;
        this.MaxFes = MaxFes;
        this.Initial_cyclesMax = 2;
    }

    public int getCyclesMax() {
        return Initial_cyclesMax;
    }

    public void setCyclesMax(int cyclesMax) {
        this.Initial_cyclesMax = cyclesMax;
    }

    /**
     *
     * @param delta nuevos valores de tamaño de paso para cada variable
     */
    public void setDelta(double[] delta) {
        this.delta = delta;
        this.eps = VectorOperations.norm(delta) / delta.length;
        //this.eps = VectorOperations.norm(delta) / (delta.length * this.MaxFes);
        //this.eps = 0.0;
        //System.out.println("Norm D = "+VectorOperations.norm(delta));
        //System.out.println(eps);
    }

    /**
     *
     * @param s
     * @param variables
     * @param base
     * @param actualFes
     * @return
     */
    public LocalSearchResult localSearch(Solution s, int[] variables, double base, int actualFes) {
        int d = variables.length;
        this.base = base;
        this.delta = new double[d];
        for (int i = 0; i < d; i++) {
            delta[i] = this.base;
        }
        return localSearch(s, variables, delta, actualFes);
    }

    /**
     *
     * @param s
     * @param variables
     * @param delta
     * @param actualFes
     * @return
     */
    public LocalSearchResult localSearch(Solution s, int[] variables, double[] delta, int actualFes) {
        LocalSearchResult lsr = new LocalSearchResult();
        
        this.variables = variables;
        int d = variables.length;
        //Initialize 
        this.setDelta(delta);

        Solution xk_1;
        Solution xk = s.clone();

        successMoves = 0;
        improvementMoves = 0;

        countEvs = 0;

        int cyclesMax = this.Initial_cyclesMax;

        int cycles = 0;
        int k = 0;
        boolean finish = false;
        Solution sExploratory = xk.clone();

        double[] deltaSubgroup = this.getDeltaSubgroup();

        while (this.normOfDelta(deltaSubgroup) > eps && cycles < cyclesMax && !finish) {

            
            
            Solution s1 = sExploratory.clone();
            Solution s2 = sExploratory.clone();

            //EXPLORATORY MOVE
            boolean success = false;
            int i = 0;
            while (i < d && !finish) {

                int index = variables[i];

                s1.getX()[index] = s1.getX()[index] + deltaSubgroup[i];
                s1.getX()[index] = Utils.boundaryHandling(index, s1.getX()[index], function.getLimits());
                s1 = this.function.evaluate(s1);

                //System.out.println("S1: "+s1);
                this.countEvs++;

                if (this.countEvs + actualFes >= this.MaxFes) {
                    finish = true;
                    if (s1.compareTo(sExploratory) <= 0) {
                        sExploratory = s1.clone();
                    }
                }

                if (!finish) {
                    s2.getX()[index] = s2.getX()[index] - deltaSubgroup[i];
                    s2.getX()[index] = Utils.boundaryHandling(index, s2.getX()[index], function.getLimits());
                    s2 = this.function.evaluate(s2);

                    //System.out.println("S2: "+s2);
                    this.countEvs++;

                    //Select the best one
                    if (s1.compareTo(s2) <= 0) {
                        if (s1.compareTo(sExploratory) <= 0) {
                            sExploratory = s1.clone();
                            s2 = s1.clone();
                            success = true;
                            this.successMoves++;
                        }
                    } else {
                        if (s2.compareTo(sExploratory) <= 0) {
                            sExploratory = s2.clone();
                            s1 = s2.clone();
                            success = true;
                            this.successMoves++;
                        }
                    }

                    if (this.countEvs + actualFes >= this.MaxFes) {
                        finish = true;
                    }
                }
                i++;
            }

            //PATRON MOVE
            if (success && (sExploratory.compareTo(xk) < 0) && (!finish)) {
                if (cycles == cyclesMax - 1) {
                    cyclesMax++;
                }
                this.improvementMoves++;

                k++;
                xk_1 = xk.clone();
                xk = sExploratory.clone();

                sExploratory.setX(VectorOperations.sum(xk.getX(), VectorOperations.rest(xk.getX(), xk_1.getX())));

                sExploratory.setX(Utils.boundaryHandling(sExploratory.getX(), function.getLimits()));

                sExploratory = function.evaluate(sExploratory);

                //System.out.println("Patron: "+sExploratory);
                this.countEvs++;
                if (this.countEvs + actualFes == this.MaxFes) {
                    finish = true;
                }
            } else {
                if (!finish) {
                    sExploratory = xk.clone();
                    deltaSubgroup = VectorOperations.div(deltaSubgroup, alpha);
                }
            }

            lsr.addConvergenceValue(xk.clone());
            
            //System.out.println(xk);
            cycles++;
        }

        //if the MaxFes was reach, verify if sExploratory is better than XK
        if (finish) {
            if (sExploratory.compareTo(xk) <= 0) {
                xk = sExploratory;
            }
        }

//        System.out.println("Norma = "+this.normOfDelta(deltaSubgroup));
//        System.out.println("In: " +s.getF()+" -- "+s.getSvr());
//        System.out.println("Out: " +xk.getF()+" -- "+xk.getSvr());
//        System.out.println("Cycles: " + cycles);
//        System.out.println("FES: " + this.countEvs);
        xk.setAge(0);
        lsr.result = xk;
        lsr.addConvergenceValue(xk.clone());
        lsr.finish = finish;

        lsr.FEs = countEvs;

        return lsr;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAlpha() {
        return alpha;
    }

    public void setAlpha(double alpha) {
        this.alpha = alpha;
    }

    public double getEps() {
        return eps;
    }

    public void setEps(double eps) {
        this.eps = eps;
    }

    public IFunctionEvaluation getFunction() {
        return function;
    }

    public void setFunction(IFunctionEvaluation ife) {
        this.function = ife;
    }

    /**
     *
     * @return retorna los tamaños de paso para las varibales del subgrupo que
     * se esta optmizando.
     */
    private double[] getDeltaSubgroup() {

        if (this.delta.length != this.variables.length) {

            double[] deltaSubgroup = new double[this.variables.length];

            for (int i = 0; i < this.variables.length; i++) {
                int index = this.variables[i];
                deltaSubgroup[i] = this.delta[index];
            }
            return deltaSubgroup;
        } else {
            return this.delta;
        }

    }

    private double normOfDelta(double[] deltaSubgroup) {
        return VectorOperations.norm(deltaSubgroup);
    }

    public static void main(String[] args) {
        IFunctionEvaluation f = new SuiteCeC2006(11);
        Solution s = new Solution(f.getDimension(), f.getNumberIConstraints(), f.getNumberEConstraints());
        double[] v = {-0.4, 0.4};
        s.setX(v);
        f.evaluate(s);
        System.out.println(s);

        HookeJeevesM ls = new HookeJeevesM(2, Integer.MAX_VALUE / 2, f);
        int variables[] = {0, 1};
        ls.setCyclesMax(Integer.MAX_VALUE);
        LocalSearchResult lsr = ls.localSearch(s, variables, new double[]{0.1, 0.1}, 0);

        System.out.println(lsr.result);
        System.out.println(lsr.FEs);
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.localsearch;

import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;


/**
 *
 * @author adam
 */
public interface ILocalSearch {
    LocalSearchResult localSearch(Solution solution);
    void setFunction(IFunctionEvaluation ife);
}

package largescaletesis.algorithm.memeticDE;

import evoutils.algorithms.DE.CrossOver;
import evoutils.algorithms.DE.Mutations;
import evoutils.algorithms.IBasicAlgorithm;
import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population;
import evoutils.utils.Utils;
import java.util.Arrays;
import java.util.LinkedList;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

/**
 * Experiment two, the FEs for local search are static at 30% of MAXFEs, 
 * and it will be distributed on the maximum cycles, it considering the minimum 
 * evaluations wastes by the local search
 * @author EkBalam
 */
public class MemeticDecompositionDE1_exp2 implements IBasicAlgorithm {

    private String name = "MDDE";
    private IFunctionEvaluation function = null;

    private final double F, CR;
    private final int NP;
    private final int MaxFes;
    private final int dimension;
    //private ArrayList<Solution> pop;
    private Population pop;

    private long time;
    boolean finish = false;

    private HookeJeevesM localS;

    //Results 
    public RunResults results;
    public LinkedList<Solution> betterSolutions;

    public MemeticDecompositionDE1_exp2(double F, double CR, int SN, int MaxFes, int dimension) {
        this.F = F;
        this.CR = CR;
        this.NP = SN;
        this.MaxFes = MaxFes;
        this.dimension = dimension;
        //this.pop = new ArrayList<>();
        this.pop = new Population(this.NP);
        this.time = 0;
        this.finish = false;
        this.betterSolutions = new LinkedList<>();
        this.results = new RunResults();
        Solution.generalTolerance = 1e-20;
    }

    public RunResults run() {
        this.runAlgorithm();
        return this.results;
    }

    @Override
    public void runAlgorithm() {

        this.time = System.currentTimeMillis();

        int fes = this.NP;
        int fesGlobal = this.NP;
        int localFEs = 0;
        
        int MaxLocalFEs = (int) (this.MaxFes * 0.3);
        int fesApplyLocal = (int) ( (4*this.dimension) / (0.3 * this.NP));
        //int fesApplyLocal = (int) ((this.MaxFes*0.7*0.7)/(this.NP*this.NP*0.3));
        //int fesApplyLocalFBa = 1;
        //int fesApplyLocal = 2;
        int vecesAplicado = 0;
        System.out.println("APLICAR CADA "+ fesApplyLocal + " Ciclos");
        
        
        this.pop.initializePop(function);

        this.betterSolutions.add(this.pop.getBest().clone());
        System.out.println(this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());

        int c = 0;
        while ((fes < this.MaxFes) && (!finish)) {

            Population popg = new Population(this.NP);
            int i = 0;

            while (i < this.NP && (!finish)) {

                Solution x = this.pop.getAt(i);
                Solution xg = rand1binOp(i);
                fes++;
                fesGlobal++;

                if (x.compareTo(xg) < 0) {
                    popg.replaceAt(i, x);
                } else {
                    popg.replaceAt(i, xg);
                }

                if (fes == this.MaxFes) {
                    finish = true;
                }
                i++;

            }

            if (finish && (i < this.NP)) {
                for (int j = i; j < this.NP; j++) {
                    popg.replaceAt(j, this.pop.getAt(j));
                }
            }
            this.pop = popg;

            //LOCAL SEARCH PHASE
            if (localFEs < MaxLocalFEs && c % fesApplyLocal == 0 && (!finish)) {
                //System.out.println(fes);
                int fesls = this.localSearchPhase(this.pop.getBestIndex(), fes);
                fes += fesls;
                localFEs += fesls;
                vecesAplicado++;
                
                //int aux = fesApplyLocal;
                //fesApplyLocal += fesApplyLocalFBa;
                //fesApplyLocalFBa = aux;
                //System.out.println("FIBONACI "+fesApplyLocal);
            }

            this.betterSolutions.add(this.pop.getBest().clone());

            this.results.addBestG(this.betterSolutions.getLast().getF(), 
                    this.betterSolutions.getLast().getSvr(), fes);

            //System.out.println(this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());
            c++;
        }

        this.time = System.currentTimeMillis() - this.time;

        Solution best = this.pop.getBest();

        System.out.println("Final FES :" + fes + " FES Global = " + fesGlobal + " Fes local :" + localFEs + " Final Cycles: " + c);
        System.out.println("Local Aplicado :" + vecesAplicado + " Promedio Evals Locales = " + localFEs / vecesAplicado );

        System.out.println(best);

        //System.out.println(time / 1000);
        this.results.setFinalX(best.getX());
        this.results.setFinalbestF(best.getF(), best.getSvr());
        this.results.setGlobalFes(fesGlobal);
        this.results.setLocalFes(localFEs);
        
    }

    private Solution rand1binOp(int i) {
        int ng = this.function.getNumberIConstraints();
        int nh = this.function.getNumberEConstraints();

        int[] perm = Utils.randperm(this.NP);
        Solution x = this.pop.getAt(i);
        Solution r1 = this.pop.getAt(perm[0]);
        Solution r2 = this.pop.getAt(perm[1]);
        Solution r3 = this.pop.getAt(perm[2]);

        double[] v = Mutations.rand1(this.F, r1.getX(), r2.getX(), r3.getX());
        double[] target = x.getX();
        double[] trial = CrossOver.binomial(target, v, CR);
        trial = Utils.boundaryHandling(trial, function.getLimits());
        Solution r = new Solution(dimension, ng, nh);
        r.setX(trial);
        this.function.evaluate(r);
        return r;
    }

    @Override
    public void setFunction(IFunctionEvaluation function) {
        this.function = function;
        this.localS = new HookeJeevesM(2, this.MaxFes, this.function);
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public long getTime() {
        return time;
    }

    private int localSearchPhase(int index, int fes) {

        int[] variables = new int[this.dimension];
        for (int i = 0; i < this.dimension; i++) {
            variables[i] = i;
        }

        Solution s = this.pop.getAt(index);

        //System.out.println("IN: " + s.getF() + " --- " + s.getSvr());

        LocalSearchResult lsresult = localS.localSearch(s, variables,0.5, fes);
        this.finish = lsresult.finish;
        if (lsresult.result.compareTo(s) <= 0) {
            this.pop.replaceAt(index, lsresult.result);

            //System.out.println("OUT: " + lsresult.result.getF() + " --- " + lsresult.result.getSvr());

        }
        return lsresult.FEs;
    }

    
    public static void main(String[] args) {
        // TODO code application logic here
        Options options = new Options();

        Option runs_value = new Option("R", "Runs", true, "Runs");
        runs_value.setRequired(false);
        options.addOption(runs_value);
        
        Option f_value = new Option("F", "F", true, "F");
        f_value.setRequired(false);
        options.addOption(f_value);

        Option cr_value = new Option("CR", "CR", true, "CR");
        cr_value.setRequired(false);
        options.addOption(cr_value);
        
        Option np_value = new Option("NP", "NP", true, "NP");
        np_value.setRequired(false);
        options.addOption(np_value);
        
        Option d_value = new Option("D", "Dimension", true, "D");
        d_value.setRequired(true);
        options.addOption(d_value);
        
        Option funct_value = new Option("Funct", "Function", true, "Function");
        funct_value.setRequired(true);
        options.addOption(funct_value);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
            return;
        }

        int runs = Integer.valueOf(cmd.getOptionValue("R", "25"));
        double F = Double.valueOf(cmd.getOptionValue("F","0.51"));
        double CR = Double.valueOf(cmd.getOptionValue("CR","0.73"));
        int    NP = Integer.valueOf(cmd.getOptionValue("NP","56"));
        int    function = Integer.valueOf(cmd.getOptionValue("Funct"));
        int    dimension = Integer.valueOf(cmd.getOptionValue("D"));
        
        
        int MaxFes = 20000*dimension;
        //int runs = 25;
        
        String folder = "./MDEv2/Expd"+dimension+"/";
        
        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        //IFunctionEvaluation f = new SuiteCeC2010_LS(function,dimension);
        ExperimentRuns er4 = new ExperimentRuns(folder, "AlgorithmName", f.getFunctionName());

        for (int e = 0; e < runs; e++) {
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e);

            MemeticDecompositionDE1_exp2 mdde4 = new MemeticDecompositionDE1_exp2(F, CR, NP, MaxFes, dimension);
            er4.setAlgorithmName(mdde4.getName());

            mdde4.setFunction(f);

            RunResults r4 = mdde4.run();
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
            System.out.println(Arrays.toString(r4.getFinalbestF()));
            er4.addRunResult(r4);
        }
                   
        er4.exportData();

    }
    
}

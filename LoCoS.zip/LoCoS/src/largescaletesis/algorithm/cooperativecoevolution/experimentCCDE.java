/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.cooperativecoevolution;

import evoutils.functions.IFunctionEvaluation;
import java.util.Arrays;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

/**
 *
 * @author Adan
 */
public class experimentCCDE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Options options = new Options();

        Option alg_value = new Option("A", "Algorithm", true, "Algorithm");
        alg_value.setRequired(true);
        options.addOption(alg_value);
        
        Option runs_value = new Option("R", "Runs", true, "Runs");
        runs_value.setRequired(false);
        options.addOption(runs_value);
        
        Option f_value = new Option("F", "F", true, "F");
        f_value.setRequired(false);
        options.addOption(f_value);

        Option cr_value = new Option("CR", "CR", true, "CR");
        cr_value.setRequired(false);
        options.addOption(cr_value);
        
        Option np_value = new Option("NP", "NP", true, "NP");
        np_value.setRequired(false);
        options.addOption(np_value);
        
        Option d_value = new Option("D", "Dimension", true, "D");
        d_value.setRequired(true);
        options.addOption(d_value);
        
        Option funct_value = new Option("Funct", "Function", true, "Function");
        funct_value.setRequired(true);
        options.addOption(funct_value);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
            return;
        }

        int alg = Integer.valueOf(cmd.getOptionValue("A","1"));
        int runs = Integer.valueOf(cmd.getOptionValue("R", "25"));
        double F = Double.valueOf(cmd.getOptionValue("F","0.51"));
        double CR = Double.valueOf(cmd.getOptionValue("CR","0.73"));
        int    NP = Integer.valueOf(cmd.getOptionValue("NP","56"));
        int    function = Integer.valueOf(cmd.getOptionValue("Funct"));
        int    dimension = Integer.valueOf(cmd.getOptionValue("D"));
        
        
        int MaxFes = 20000*dimension;
        //int runs = 25;
        
        
        String folder = "./MDEv2/Expd"+dimension+"/";
        
        switch(alg){
            case 1: folder = "./CCDE_DVIIC/Expd"+dimension+"/"; break;
            case 2: folder = "./CCDE_DG2/Expd"+dimension+"/"; break;
            case 3: folder = "./CCDE_DVIIC_Once/Expd"+dimension+"/"; break;
        }
        
        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        //IFunctionEvaluation f = new SuiteCeC2010_LS(function,dimension);
        ExperimentRuns er4 = new ExperimentRuns(folder, "AlgorithmName", f.getFunctionName());

        for (int e = 0; e < runs; e++) {
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e);

            switch(alg){
                case 1:{ CC_DE_DVIIC ccde = new CC_DE_DVIIC(f, NP, MaxFes, 100); 
                        er4.setAlgorithmName(ccde.getName());
                        RunResults r4 = ccde.run();
                        System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
                        System.out.println(Arrays.toString(r4.getFinalbestF()));
                        er4.addRunResult(r4);
                       }
                        break;
                case 2:{
                        CC_DE_DG2 ccde = new CC_DE_DG2(f, NP, MaxFes, 100);
                        er4.setAlgorithmName(ccde.getName());
                        RunResults r4 = ccde.run();
                        System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
                        System.out.println(Arrays.toString(r4.getFinalbestF()));
                        er4.addRunResult(r4);
                       }
                        break;
                case 3:{
                        CC_DE_DVIIC_once ccde = new CC_DE_DVIIC_once(f, NP, MaxFes, 100);
                        er4.setAlgorithmName(ccde.getName());
                        RunResults r4 = ccde.run();
                        System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
                        System.out.println(Arrays.toString(r4.getFinalbestF()));
                        er4.addRunResult(r4);
                       }
                        break;
                    
            }
            
        }
        er4.exportData();
    }
    
}

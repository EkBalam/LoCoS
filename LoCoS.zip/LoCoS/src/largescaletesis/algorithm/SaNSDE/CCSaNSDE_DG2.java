/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.SaNSDE;

import evoutils.algorithms.IBasicAlgorithm;
import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SubProblemEvaluation;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population;
import evoutils.utils.Utils;
import java.util.Arrays;
import java.util.logging.Logger;
import largescaletesis.algorithm.differentialgrouping2.DifferentialGrouping2;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import viicstay.representation.Dvector;

/**
 * Improvement at 19/02/2018
 * @author Adan
 */
public class CCSaNSDE_DG2 implements IBasicAlgorithm{
    public final static Logger LOGGER = Logger.getLogger(CCSaNSDE_DG2.class.getName());
    private String name = "CCSaNSDE_DG2";
    
    private IFunctionEvaluation function;
    private SubProblemEvaluation subfunction;
    
    private boolean finish = false;
    
    private int PopSize;
    private Population[] popK;
    public Solution best;

    private int max_Fes;
    private int fes;
    private int max_Iter;
    //Crm for SaNSDE
    private double Crm = 0.5;
    
    public RunResults results;
    private long time;
    
    public CCSaNSDE_DG2(IFunctionEvaluation function, int PopSize, int max_Fes, int max_Iter){
        this.function = function;
        this.PopSize = PopSize;
        this.max_Fes = max_Fes;
        this.max_Iter = max_Iter;
    }
    
    
    public RunResults run(){
        RunResults rr = new RunResults();
        
        Solution.generalTolerance = 1e-20;

        Population pop = new Population(this.PopSize, this.function);
        
        //int fes_viic = (int) (this.max_Fes * 0.1);
        //int fes_viic = (int) (this.max_Fes * 0.001);
        //System.out.println("Fes dviic = " + fes_viic);

        this.fes = this.PopSize;//+viics.evals;

        this.best = pop.getBest().clone();
        System.out.println("Best inicial:\n [ " + this.best.f +", "+this.best.getSvr()+" ]");

        //DECOMPOSITION
        DifferentialGrouping2 dg2 = new DifferentialGrouping2(this.function);
        int [] group = dg2.groups(dg2.tetha, this.function.getDimension());
        Dvector des = new Dvector(this.function.getDimension());
        des.setVarArrGroup(group);
        //System.out.println(des);
        
        while (!finish && fes < this.max_Fes) {
                        
            popK = new Population[des.getNumberSubgroups()];
            
            int to, from = 0;
            //this.max_Iter = des.getNumberSubgroups();
            //System.out.print(" "+this.max_Iter);
            
            Solution contexVector = best.clone();
            
            for (int i = 0; i < des.getNumberSubgroups(); i++) {
                //System.out.println(this.Crm);
                
                to = from + des.getVsubproblemSizes()[i];
                
                //SUBPROBLEMS
                int[] varSub = Arrays.copyOfRange(des.getArrangement(),from, to);
                popK[i] = subPopulations(pop, this.best, varSub);
                this.fes += this.PopSize;

                //CONTEX VECTOR and EVALUATOR
                this.subfunction = new SubProblemEvaluation(this.function);    
                this.subfunction.setContexSolution(contexVector);
                this.subfunction.setSubProblemVariables(varSub);
                
                //OPTIMIZER
                int optimizerEvals = this.PopSize*this.max_Iter;
                if((fes + optimizerEvals) > this.max_Fes){
                    if( des.getNumberSubgroups() > 1){
                        optimizerEvals = (int)Math.ceil((double)(this.max_Fes-this.fes-this.PopSize)/ (double)this.PopSize);
                    }else{
                        optimizerEvals = (int)Math.ceil((double)(this.max_Fes-this.fes)/(double)this.PopSize);
                    }
                }
                
                
                SaNSDE sansde = new SaNSDE(this.subfunction,
                                           this.PopSize,optimizerEvals,100);
                sansde.setCRm(this.Crm);
                sansde.setFunction(this.subfunction);
                sansde.run(popK[i].getArrayPop());
                
                this.Crm = sansde.getCRm();
                Solution[] popResult = sansde.getPop();
                
                this.fes += (optimizerEvals);
                
                //UPDATE POPK
                for(int is = 0; is < this.PopSize; is++){
                    popK[i].replaceAt(is, popResult[is]);
                }
                
                //UPDATE CONTEX VECTOR
                if(popK[i].getBest().compareTo(contexVector) <= 0){
                    for(int v = 0; v < varSub.length; v++){
                        contexVector.setValueAt(varSub[v], popK[i].getBest().getX()[v]);
                    }
                    contexVector.f = popK[i].getBest().f;
                    contexVector.g = popK[i].getBest().g;
                    contexVector.h = popK[i].getBest().h;
                    contexVector.getSvr();
                }
                
                from = to;
            }
            pop = this.joinPopk(popK, des);
            pop.evalAll(function);
            
//            System.out.println("BEST POPK UNIDO \n"+pop.getBest());
//            System.out.println("BEST  \n"+best);
//            System.out.println("FRES: "+ this.fes);
//            System.out.println("Contex Vector  \n"+contexVector);
            
            if(contexVector.compareTo(this.best) <= 0){
                this.best = contexVector;
            }
            
            rr.addBestG(this.best.getF(), this.best.getSvr(), this.fes);
            
        }
        
        //RESULTS
        rr.setFinalbestF(best.getF(), best.getSvr());
        
//        System.out.println("\nBest "+best);
//        System.out.println("DVIIC evals = " + dviicEvals);
//        System.out.println("DVIIC calls = " + (dviicEvals / fes_viic));
//        System.out.println("FES = "+this.fes);
        
        return rr;
    }
    
    private Population joinPopk(Population[] popK, Dvector des) {
        Population paux = new Population(this.PopSize);

        for (int s = 0; s < this.PopSize; s++) {
            Solution sn = new Solution(this.function.getDimension(),
                    this.function.getNumberIConstraints(),
                    this.function.getNumberEConstraints(),1e-20);
            int to, from = 0;

            for (int j = 0; j < des.getNumberSubgroups(); j++) {
                to = from + des.getVsubproblemSizes()[j];
                int[] varSub = Arrays.copyOfRange(des.getArrangement(), from, to);

                for (int v = 0; v < varSub.length; v++) {
                    int index = varSub[v];
                    sn.setValueAt(index, popK[j].getAt(s).getX()[v]);
                }

                paux.replaceAt(s, sn);

                from = to;
            }
        }
        return paux;
    }
    
    private Population subPopulations(Population pop, Solution best, int[] varSub) {
        
        Population popk = new Population(pop.getNp());
        
        int subDimension = varSub.length;
        
        for (int i = 0; i < popk.getNp(); i++) {

            Solution s = new Solution(subDimension,this.function.getNumberIConstraints(), 
                                            this.function.getNumberEConstraints(),1e-20);

            for (int j = 0; j < varSub.length; j++) {
                s.setValueAt(j, pop.getAt(i).getX()[varSub[j]]);
            }
            
            popk.replaceAt(i, s);
        }

        return popk;
    }
        
    @Override
    public void runAlgorithm() {
        this.run();
    }

    @Override
    public void setFunction(IFunctionEvaluation function) {
        this.function = function;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name  = name;
    }
    
    
    public static void main(String[] args) {
        
        int NP = 50;
        int dimension = 1000;
        int maxFes = 200 * dimension;
        int maxIter = 100;
        
        int runs = 1;
        int function = 3;
        FunctionsSayed fs = new FunctionsSayed(function, dimension);
        
        int feasiblesRuns = 0;
        double fit [] = new double[runs];
        for (int i = 0; i < runs; i++) {
            CCSaNSDE_DG2 ccde = new CCSaNSDE_DG2(fs, NP, maxFes, maxIter);
            RunResults rr = ccde.run();
            fit[i] = ccde.best.f;
            System.out.println("F: "+ccde.best.f+" --- "+ccde.best.svr);            
            if (ccde.best.svr == 0) {
                feasiblesRuns++;
            }
           
        }
        
        System.out.println("Stats F = "+ Arrays.toString(Utils.getStatistics(fit)));
        System.out.println("Feasibles = " + feasiblesRuns);
 
        //cg.getChartFrame().setVisible(true);
        
    }
    
    
    
}

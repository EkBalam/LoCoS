/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.SaNSDE;

import evoutils.algorithms.DE.CrossOver;
import evoutils.algorithms.DE.Mutations;
import evoutils.algorithms.IBasicAlgorithm;
import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population;
import evoutils.utils.Utils;
import evoutils.utils.VectorOperations;
import java.util.ArrayList;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.math3.distribution.CauchyDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;

/**
 *
 * @author EkBalam
 */
public class SaNSDE implements IBasicAlgorithm{
    
    public static void main(String[] args) {
        int dimension = 100;
        int maxFes = 20000 * dimension;
        int maxGen = 100;
        int function = 1;
        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        
        SaNSDE sansde = new SaNSDE(f,100,maxFes,maxGen);
        sansde.runAlgorithm();
    }
    
    String name = "SaNSDE";
    
    private IFunctionEvaluation func;
    Population pop = null;
    int np;
    
    int maxFes, maxGenerations;
    
    //Mutation Strategies
    double p = 0.5;
    int ns1, ns2, nf1, nf2;
    
    int learningPeriod = 50;
    
    //self adaptative scale-factor
    double fp = 0.5;
    int nsf1, nsf2, nff1, nff2;
    
    //self adaptative cross ratio
    double CR;
    double CRm = 0.5;
    ArrayList<Double> CRrec = new ArrayList<>();
    ArrayList<Double> Frec = new ArrayList<>();
    int keepCR = 5;
    int updateCRm = 25;

    public RunResults results;
    public SaNSDE(IFunctionEvaluation func, int np, int maxFes, 
            int maxGenerations) {
        this.func = func;
        this.np = np;
        this.maxFes = maxFes;
        this.maxGenerations = maxGenerations;
    }
    
    public RunResults run(Solution[] ipop){
        this.pop = new Population(this.np);
        for(int i = 0; i<this.np; i++){
            this.pop.replaceAt(i, ipop[i]);
        }
        this.runAlgorithm();
        return this.results;
    }
    
    @Override
    public void runAlgorithm() {
        Solution.generalTolerance = 1e-4;
        Solution.PRINT_X = false;
        
        //Mutation strategies
        ns1 = 0; ns2 = 0; nf1 = 0; nf2 = 0;
        
        //Scale factor adaptative
        nsf1 = 0; nsf2 = 0; nff1 = 0; nff2 = 0;
        
        if(this.pop == null){
            this.pop = new Population(this.np, this.func);
        }else{
            this.pop.evalAll(func);
        }
        
        CR = new NormalDistribution(this.CRm,0.1).sample();
        
        int GEN = 1;
        int FES = this.np;
        while((FES < this.maxFes) || (GEN < this.maxGenerations)){
            
            Solution best = this.pop.getBest();
            
            this.updateProbabilitiesValues(GEN);
                        
            Population newPop = new Population(this.np);
            for(int i = 0; i < this.np; i++){
                //Flags to know what version is performed
                //Mutation true: rand1bin false: currenttobest
                //ScaleFactor true: normal disttibution, false: cauchy distribution
                boolean flagMutation = Utils.randInterval(0, 1) < this.p;
                boolean flagFactor = Utils.randInterval(0, 1) < this.fp;
                
                Solution newSolution = this.operators(i, best, flagMutation, flagFactor);
                FES++;
                Solution current = pop.getAt(i);
                //New Solution better than current
                if(newSolution.compareTo(current) <= 0){
                    newPop.replaceAt(i, newSolution);
                    //Muation count
                    this.ns1 += flagMutation ? 1 : 0;
                    this.ns2 += flagMutation ? 0 : 1;
                    //scale factor
                    this.nsf1 += flagFactor ? 1 : 0;
                    this.nsf2 += flagFactor ? 0 : 1;
                    //CRrec
                    this.CRrec.add(this.CR);
                    this.Frec.add((current.getF()-newSolution.getF()));
                }else{
                    newPop.replaceAt(i,current);
                    //Muation count
                    this.nf1 += flagMutation ? 1 : 0;
                    this.nf2 += flagMutation ? 0 : 1;
                    //scale factor
                    this.nff1 += flagFactor ? 1 : 0;
                    this.nff2 += flagFactor ? 0 : 1;
                }
            }
            this.pop = newPop;
            GEN++;
//            if(FES % 10000 ==0){
//                System.out.println("Evals " + FES);
//                System.out.println(this.pop.getBest());
//            }
        }
    }
    
    /**
     * Updates all probablities values and CRm
     * fp: factor scale probability
     * p : mutation strategie probability
     * CRm: CR mean
     * CR: Croos Ratio value 
     * @param GEN current generation
     */
    public void updateProbabilitiesValues(int GEN){
        //UPDATE PROBABILITIES
            if(GEN % this.learningPeriod == 0){
                this.fpUpdate();
                this.pUpdate();
            }
            //UPDATE CRm
            if(GEN % this.updateCRm == 0){
                this.crmUpdate();
                CRrec = new ArrayList<>();
                Frec = new ArrayList<>();
            }
            //UPDATE CR
            if(GEN % this.keepCR == 0){
                CR = new NormalDistribution(this.CRm,0.1).sample();
            }
    }
    
    /**
     * Calculate and return the new value of the Factor Scale 
     * @param flagFactor
     * @return new FactorScale
     */
    public double newF(boolean flagFactor){
        return flagFactor 
                ? new NormalDistribution(0.5, 0.3).sample()
                : new CauchyDistribution().sample();
    }
    
    /**
     * Updates the CRm value
     */
    public void crmUpdate(){
        int length = this.CRrec.size();
        double[] w = new double[length];
        
        double sumFrec = 0.0;
        for(int i = 0; i < length; i++){
            sumFrec += this.Frec.get(i);
        }      
                
        for(int i = 0; i < length; i++){
            if(sumFrec != 0)
                w[i] = this.Frec.get(i) / sumFrec;
            else{
                w[i] = this.Frec.get(i);
            }
        }
        
        double newCRm = 0.0;
        for(int i = 0; i < length; i++){
            newCRm += w[i]*this.CRrec.get(i);
        }

        this.CRm = newCRm;
    }
    
    /**
     * Update the probability value for scale factor distribution
    */
    public void fpUpdate(){
        
        double div = ( (nsf2*(nsf1+nff1)) + (nsf1*(nsf2+nff2)) );
        this.fp = div != 0 ? (nsf1 * (nsf2 + nff2)) / div: this.fp;      
        nsf1 = 0; nsf2 = 0; nff1 = 0; nff2 = 0;
    }
    
    /**
     *Update the probability value for mutation strategies
     */
    public void pUpdate(){
        double div = ( (ns2*(ns1+nf1)) + (ns1*(ns2+nf2)) );
        this.p = div != 0 ? (ns1 * (ns2 + nf2)) / div : this.p;
        ns1 = 0; ns2 = 0; nf1 = 0; nf2 = 0;
    }

    private Solution operators(int i, Solution best, boolean flagMutation,
            boolean flagFactor) {
        Solution ng = best.clone();
        double F = this.newF(flagFactor);
        double[] mutan;
        
        int[] xrs = Utils.randIndexDiff(i, np, 3);
        double[] current = this.pop.getAt(i).getX();
        double[] xr1 = this.pop.getAt(xrs[0]).getX();
        double[] xr2 = this.pop.getAt(xrs[1]).getX();
        double[] xr3 = this.pop.getAt(xrs[2]).getX();
        
        if(flagMutation){
            mutan = Mutations.rand1(F, xr1, xr2, xr3);
        }else{
            mutan = this.current_to_2best(F, F, current, best.getX(), xr1, xr2);
        }
        
        double[] trial = CrossOver.binomial(current, mutan, this.CR);
        trial = Utils.boundaryHandling(trial, this.func.getLimits());
        
        ng.setX(trial);
        ng = this.func.evaluate(ng);
        
        return ng;
    }
        
    public double[] current_to_2best (double F1, double F2, double[] current, 
            double[] best, double[] r1, double[] r2){
        double[] mutant = new double[r1.length];
        double[] sum1 = VectorOperations.mult(VectorOperations.rest(best, current), F1);
        double[] sum2 = VectorOperations.mult(VectorOperations.rest(r2, r2), F2);
        double[] sumR = VectorOperations.sum(sum1, sum2);
        mutant = VectorOperations.sum(current, sumR);
        return mutant;
    }
    
    @Override
    public void setFunction(IFunctionEvaluation ife) {
        this.func = ife;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    } 

    public double getCRm() {
        return CRm;
    }

    public void setCRm(double CRm) {
        this.CRm = CRm;
    }
    
    public Solution[] getPop(){
        Solution[] returnPop = new Solution[this.np];
        System.arraycopy(this.pop.getArrayPop(), 0, returnPop, 0, this.np);
        return returnPop;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.dinamycVIIC;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.SuiteCeC2010_LS;
import evoutils.solutions.Solution;
import evoutils.utils.SaveDataFile;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

/**
 *
 * @author Adan
 */
public class DelocosDviccExperiment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Options options = new Options();

        Option runs_value = new Option("R", "Runs", true, "Runs");
        runs_value.setRequired(false);
        options.addOption(runs_value);
        
        Option f_value = new Option("F", "F", true, "F");
        f_value.setRequired(false);
        options.addOption(f_value);

        Option cr_value = new Option("CR", "CR", true, "CR");
        cr_value.setRequired(false);
        options.addOption(cr_value);
        
        Option np_value = new Option("NP", "NP", true, "NP");
        np_value.setRequired(false);
        options.addOption(np_value);
        
        Option d_value = new Option("D", "Dimension", true, "D");
        d_value.setRequired(true);
        options.addOption(d_value);
        
        Option funct_value = new Option("Funct", "Function", true, "Function");
        funct_value.setRequired(true);
        options.addOption(funct_value);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
            return;
        }

        int runs = Integer.valueOf(cmd.getOptionValue("R", "25"));
        double F = Double.valueOf(cmd.getOptionValue("F","0.51"));
        double CR = Double.valueOf(cmd.getOptionValue("CR","0.73"));
        int    NP = Integer.valueOf(cmd.getOptionValue("NP","56"));
        int    function = Integer.valueOf(cmd.getOptionValue("Funct"));
        int    dimension = Integer.valueOf(cmd.getOptionValue("D"));
        
        
        int MaxFes = 20000*dimension;
        //int runs = 25;
        Solution.PRINT_X = false;
        
        String folder = "./DELOCOS_DVIIC_once/Expd"+dimension+"/";
        
        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        //IFunctionEvaluation f = new SuiteCeC2010_LS(function,dimension);
        ExperimentRuns er4 = new ExperimentRuns(folder, "AlgorithmName", f.getFunctionName());
        double[] means = new double[runs];
        String[] dataMeanK = new String[runs];
        for (int e = 0; e < runs; e++) {
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e);

            DELOCOS_DVIIC_Once mdde4 = new DELOCOS_DVIIC_Once(F, CR, NP, MaxFes, dimension);
            er4.setAlgorithmName(mdde4.getName());

            mdde4.setFunction(f);

            RunResults r4 = mdde4.run();
            System.out.println("Function: " + f.getFunctionName() + " Run: " + e + "\n");
            System.out.println(Arrays.toString(r4.getFinalbestF()));
            er4.addRunResult(r4);
            means[e] = (double)mdde4.K_subgroups/(double)mdde4.N_decompositions;
            dataMeanK[e] = "["+(double)mdde4.K_subgroups+","+(double)mdde4.N_decompositions+"]";
        }
   
//        try {
//            SaveDataFile.saveString(folder + "MeanK_subgroups.txt" , f.getFunctionName()+" = "+Arrays.toString(means)+";");
//            SaveDataFile.saveString(folder + "MeanK_subgroups.txt" , f.getFunctionName()+"_raw = "+Arrays.toString(dataMeanK)+";");
//        } catch (IOException ex) {
//            Logger.getLogger(DelocosDviccExperiment.class.getName()).log(Level.SEVERE, null, ex);
//        }
        
        er4.exportData();

    }
    
}

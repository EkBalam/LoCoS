/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm;

import evoutils.functions.IFunctionEvaluation;
import evoutils.utils.SaveDataFile;
import evoutils.utils.Utils;
import largescaletesis.functions.constrained.BasicFunctionsSayed;
import largescaletesis.functions.constrained.FunctionsSayed;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

/**
 * @author EkBalam
 */
public class VIIC_O {

    /**
     *
     */
    private int max_constr;
    /**
     * Max iterations of optimising each subproblem
     */
    private final int max_gprsiter;
    /**
     * size of each subproblem
     */
    private int[] V;
    /**
     * subproblems
     */
    private final int m;
    /**
     * is expected to have a reasonable number of different variables
     * arrangements
     */
    private final LinkedList<int[]> gprsPool;

    FunctionsSayed function;

    private final int dimension;
    private int evalsConstraints;
    private int evalsObjectiveFunction;
    private int callEval;
    public int totalCallEvals;

    public double[] gprsDiffs;
    public double[] gprsDiffsSN;
    public ArrayList<ArrayList<Double>> convergence;
    
    public int[] iterations;

    public VIIC_O(int m, FunctionsSayed function) {
        this.m = m;
        this.function = function;
        this.dimension = function.getDimension();
        this.max_gprsiter = this.m * 10000;
        this.gprsPool = new LinkedList<>();
        this.createV();
        this.evalsConstraints = 0;
        this.evalsObjectiveFunction = 0;
        this.callEval = 0;
        this.totalCallEvals = 0;
    }

    public int[] getDecomposition(boolean feasible) {

        int functionEval = this.function.getNumberIConstraints();
        max_constr = functionEval + 1;
        int c_num = 1;
        if (feasible) {
            c_num = 0;
        }
        this.callEval = 0;
        this.evalsConstraints = 0;
        this.evalsObjectiveFunction = 0;

        this.convergence = new ArrayList<>();
        this.gprsDiffs = new double[max_constr];
        this.gprsDiffsSN = new double[max_constr];
        this.iterations = new int[max_constr];
        
        //Frecuency Matrix
        LinkedList<int[]> FM = new LinkedList<>();
        double C1 = Utils.randInterval(1, this.function.getLimits()[IFunctionEvaluation.UPPER_LIMIT][0]);
        double C2 = Utils.randInterval(1, this.function.getLimits()[IFunctionEvaluation.UPPER_LIMIT][0]);
        
        while (c_num < max_constr) {
            
            ArrayList<Double> con = new ArrayList<>();
            
            int[] Sg = Utils.randperm(this.dimension);
            double fitallc1c2 = calculateFitallC1C2(C1, C2, c_num);
            double fitgroupsc1c2 = calculateFitGroupsC1C2(Sg, C1, C2, c_num);
            double grpsdiff = Math.abs(fitallc1c2 - fitgroupsc1c2);
            int grpiter = 0;
            
            con.add(grpsdiff);
            
            while (grpsdiff != 0 && grpiter < this.max_gprsiter) {
                int[] Sg1 = Utils.randperm(this.dimension);
                fitgroupsc1c2 = calculateFitGroupsC1C2(Sg1, C1, C2, c_num);
                double grpsdiffnew = Math.abs(fitallc1c2 - fitgroupsc1c2);
                if (grpsdiffnew < grpsdiff) {
                    grpsdiff = grpsdiffnew;
                    Sg = Sg1;
                }
                grpiter++;
                con.add(grpsdiff);
                //System.out.println("gprsDiff = " + grpsdiff);
            }
            this.convergence.add(con);
            this.gprsDiffs[c_num] = grpsdiff;
            this.iterations[c_num] = grpiter;
            System.out.println("gprsDiff = " + grpsdiff + "\n iTERACIONES = " + grpiter);
            FM.add(Sg);
            c_num++;
        }

        int[] Sn = createSN(FM);
        Sn = this.sortSubProblemIndex(Sn);
         
        for(int j = 0; j < max_constr; j++){
            double fitallc1c2f = calculateFitallC1C2(C1, C2, j);
            double fitgroupsc1c2f = calculateFitGroupsC1C2(Sn, C1, C2, j);
            double grpsdifff= Math.abs(fitallc1c2f - fitgroupsc1c2f);
             this.gprsDiffsSN[j] = grpsdifff;
            System.out.println(j+" Sn diff "+grpsdifff);
            
        }
        //Sn = this.sortSubProblemIndex(Sn);
        this.totalCallEvals += this.callEval;
        this.gprsPool.add(Sn);

        return Sn;
    }

    /**
     *
     * @param FM
     * @return The variable arrangement vector SN
     */
    private int[] createSN(LinkedList<int[]> FM) {

        LinkedList<Integer> Sn = new LinkedList<>();

        class IndexValue {

            public int index = 0;
            public int value = 0;

            public IndexValue(int index) {
                this.index = index;
            }

        }

        LinkedList<IndexValue> count = new LinkedList<>();

        for (int i = 0; i < this.function.getDimension(); i++) {
            count.add(new IndexValue(i));
        }

        int start = 0;
        int end = 0;

        //For every subgroup
        for (int k = 0; k < m; k++) {

            end = start + V[k];

            //Count the number of aparitons of each variable
            for (int i = start; i < end; i++) {
                for (int[] s : FM) {
                    for (int j = 0; j < count.size(); j++) {
                        if (count.get(j).index == s[i]) {
                            count.get(j).value++;
                        }
                    }
                }
            }

            Collections.sort(count, (IndexValue o1, IndexValue o2) -> {
                if (o1.value < o2.value) {
                    return 1;
                }
                if (o1.value > o2.value) {
                    return -1;
                }
                return 0;
            });

            int i = 0;
            while (!count.isEmpty() && i < V[k]) {
                IndexValue var = count.getFirst();
                Sn.add(var.index);
                count.removeFirst();
                i++;
            }

            for (IndexValue var : count) {
                var.value = 0;
            }

            start = end;
        }

        System.out.println(Sn.size());
        //System.out.println(allDifferent(Sn));

        int[] r = new int[this.dimension];
        for (int i = 0; i < this.dimension; i++) {
            r[i] = Sn.get(i);
        }

        return r;
    }

    private double calculateFitGroupsC1C2(int[] Sg, double C1, double C2, int c_num) {
        double fitgroups = 0.0;

        for (int k = 0; k < this.m; k++) {
            double[] xc1 = new double[dimension];
            double[] xc2 = new double[dimension];
            for (int i = 0; i < dimension; i++) {
                xc1[i] = C2;
                xc2[i] = C1;
            }

            int start = 0;
            if (k != 0) {
                for (int i = 0; i < k; i++) {
                    start += V[i];
                }
            }
            int end = V[k] + start;

            for (int j = start; j < end; j++) {
                xc1[Sg[j]] = C1;
                xc2[Sg[j]] = C2;
            }

            fitgroups += evalfunctionC1C2(c_num, xc1) + evalfunctionC1C2(c_num, xc2);
        }

        return fitgroups;
    }

    private double calculateFitallC1C2(double C1, double C2, int c_num) {
        double xc1[] = new double[dimension];
        double xc2[] = new double[dimension];
        double fitc1;
        double fitc2;

        for (int i = 0; i < dimension; i++) {
            xc1[i] = C1;
            xc2[i] = C2;
        }

        fitc1 = evalfunctionC1C2(c_num, xc1);

        fitc2 = evalfunctionC1C2(c_num, xc2);

        return this.m * (fitc1 + fitc2);
    }

    private double evalfunctionC1C2(int c_num, double[] xc) {
        double f = 0.0;
        this.callEval++;
        switch (c_num) {
            case 1:
                f = BasicFunctionsSayed.g01(xc);
                this.evalsConstraints++;
                break;
            case 2:
                f = BasicFunctionsSayed.g02(xc);
                this.evalsConstraints++;
                break;
            case 3:
                f = BasicFunctionsSayed.g03(xc);
                this.evalsConstraints++;
                break;
            case 0:
                f = this.evalFunction(xc);
                this.evalsObjectiveFunction++;
                break;
        }
        return f;
    }

    private double evalFunction(double[] xc) {
        int f = this.function.getFunction();
        double fit = 0.0;
        switch (f) {
            case 1:
            case 2:
            case 3:
                fit = BasicFunctionsSayed.obj1(xc);
                break;
            case 4:
            case 5:
            case 6:
                fit = BasicFunctionsSayed.obj2(xc);
                break;
            case 7:
            case 8:
            case 9:
                fit = BasicFunctionsSayed.obj3(xc);
                break;
            case 10:
            case 11:
            case 12:
                fit = BasicFunctionsSayed.obj4(xc);
                break;
            case 13:
            case 14:
            case 15:
                fit = BasicFunctionsSayed.obj5(xc);
                break;
            case 16:
            case 17:
            case 18:
                fit = BasicFunctionsSayed.obj6(xc);
                break;
        }
        return fit;
    }
    
    /**
     *
     * @return an array with the size of each subproblem
     */
    public int[] getV() {
        return V;
    }

    /**
     *
     * @return a random decomposition vector from the gprsPool
     */
    public int[] getrandGprspool() {
        if (this.gprsPool.size() > 0) {
            int s = Utils.randInt(gprsPool.size());
            return gprsPool.get(s);
        }
        return null;
    }

    public LinkedList<int[]> getGprsPool() {
        return gprsPool;
    }

    private void createV() {
        int t = (int) Math.ceil((double) this.dimension / (double) this.m);
        //Math.round(this.dimension / this.m);
        V = new int[m];
        int sum = 0;
        for (int i = 0; i < m; i++) {
            if (sum + t > dimension || i + 1 == m) {
                V[i] = dimension - sum;
            } else {
                V[i] = t;
                sum += t;
            }
        }
    }   

    public int getcallEvals() {
        return this.callEval;
    }

    public int getEvalsConstraints() {
        return evalsConstraints;
    }

    public int getEvalsObjectiveFunction() {
        return evalsObjectiveFunction;
    }

    private boolean allDifferent(LinkedList<Integer> Sn) {
        boolean alldiferents = true;
        for (int x = 0; x < Sn.size(); x++) {
            for (int z = 0; z < Sn.size(); z++) {
                if (x != z) {
                    if (Sn.get(x).equals(Sn.get(z))) {
                        alldiferents = false;
                        break;
                    }
                }
            }
            if (!alldiferents) {
                break;
            }
        }
        return alldiferents;
    }

    private int[] sortSubProblemIndex(int[] Sn) {

        int from = 0;
        int to = 0;

        for (int i = 0; i < this.V.length; i++) {
            to = from + this.V[i];

            Arrays.sort(Sn, from, to);

            from = from + this.V[i];
        }

        return Sn;
    }

    public static void main(String[] args) throws IOException {

        int[] functions = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
        int[] dimensions = {100,500,1000};
        //int[] functions = {3,18};
        //int[] dimensions = {100};
        
        int runs = 25;
        
        String folder = "./analisisVIIC2/";
        File  f = new File(folder);
        if(!f.exists()){
            f.mkdirs();
        }

        for (int d = 0; d < dimensions.length; d++) {
            for (int i = 0; i < functions.length; i++) {
                FunctionsSayed fs = new FunctionsSayed(functions[i], dimensions[d]);
                VIIC_O viic = new VIIC_O(2, fs);
                
                ArrayList<double[]> gprdiif = new ArrayList();
                ArrayList<double[]> gprdiifSn = new ArrayList();
                ArrayList<int[]> iter = new ArrayList();
                int[] callEvals = new int[25];
                
                String folderFunction = folder+"Function"+functions[i]+"/";
                File  ff = new File(folderFunction);
                if(!ff.exists()){
                    ff.mkdirs();
                }
                
                for (int r = 0; r < runs; r++) {
                    System.out.println("Function: " + functions[i]);
                    long j = System.currentTimeMillis();
                    
                    System.out.println(Arrays.toString(viic.getDecomposition(true)));
                    //System.out.println(Arrays.toString(viic.getrandGprspool()));
                    //System.out.println(viic.convergence.get(0).toString());
                    System.out.println(System.currentTimeMillis() - j);
                    System.out.println("Call Eval = " + viic.getcallEvals());
                    System.out.println("Total CallEval = " + viic.totalCallEvals+"\n");
                    
                    gprdiif.add(viic.gprsDiffs);
                    gprdiifSn.add(viic.gprsDiffsSN);
                    iter.add(viic.iterations);
                    callEvals[r] = viic.getcallEvals();
                    
                    int constr = 1;
                    for(ArrayList<Double> c : viic.convergence){
                        SaveDataFile.saveStringln(folderFunction + "D"+ dimensions[d]+".m", "F"+functions[i]+
                                "_r"+r+"F"+constr+
                                " = "+c.toString());
                        constr++;
                    }
                    
                }
                
                String gprs = "[";
                String gprsSnF = "[";
                String iters = "[";
                for( int gi = 0; gi < gprdiif.size(); gi++){
                    
                    double[] gprsv = gprdiif.get(gi);
                    double[] gprsSn = gprdiifSn.get(gi);
                    
                    int[] iterv = iter.get(gi);
                    
                    for( int h = 0; h < gprsv.length; h++){
                        gprs += gprsv[h]+" ";
                        gprsSnF += gprsSn[h]+" ";
                        iters += iterv[h]+" ";
                    }
                    gprs += ";";
                    gprsSnF += ";";
                    iters += ";";
                }
                gprs += "];";
                gprsSnF += "];";
                iters += "];";
                
                SaveDataFile.saveStringln(folder + "D"+ dimensions[d]+".m", "F"+functions[i]+"_gprdiif = "+gprs);
                SaveDataFile.saveStringln(folder + "D"+ dimensions[d]+".m", "F"+functions[i]+"_gprdiifSN = "+gprsSnF);
                SaveDataFile.saveStringln(folder + "D"+ dimensions[d]+".m", "F"+functions[i]+"_iters = "+iters);
                SaveDataFile.saveStringln(folder + "D"+ dimensions[d]+".m", "F"+functions[i]+"_callevals = "+Arrays.toString(callEvals));

            }
        }

    }

}

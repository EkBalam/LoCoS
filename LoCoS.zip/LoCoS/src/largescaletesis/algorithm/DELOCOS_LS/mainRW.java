/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.DELOCOS_LS;

import evoutils.functions.IFunctionEvaluation;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class mainRW extends ForkJoinTask {

    int[] function = {1};
    int runs = 1;

    double F = 0.5, CR = 0.9;
    int NP = 100;

    int MaxFes = 10000000;
    int dimension = 500;
    String folder = "./test/d500/";
    int m = 2;

    public mainRW(int[] function, int dimension, double F, double CR, int NP, int MaxFes, int runs, String folder, int m) {
        this.function = function;
        this.dimension = dimension;
        this.F = F;
        this.CR = CR;
        this.NP = NP;
        this.MaxFes = MaxFes;
        this.runs = runs;
        this.folder = folder;
        this.m = m;
    }

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int[] function = { 2 };
        //int[] function = {1};

        int exp = 1;
        String folderExpd100 = "./DELOCOSRW/Exp" + exp + "d100/";
        //String folderExpd500 = "./DELOCOSRW/Exp" + exp + "d500/";
        String folderExpd1000 = "./DELOCOSRW/Exp" + exp + "d1000/";
        //int[] function = {1};
        int runs = 5;

        double F = 0.5, CR = 0.9;
        int NP = 100;
        int[] ms = {2};
        int MaxFes100 = 2000000;
        int MaxFes500 = 10000000;
        int MaxFes1000 = 20000000;
        
        
        for (int i = 0; i < ms.length; i++) {

            //String folderExpd100 = "./test/Exp" + exp + "d100_M_"+ms[i]+"/";
            //String folderExpd500 = "./test/Exp" + exp + "d500_M_"+ms[i]+"/";
            //String folderExpd1000 = "./test/Exp" + exp + "d1000_M_"+ms[i]+"/";

            ForkJoinPool pool = new ForkJoinPool(Runtime.getRuntime().availableProcessors());

            mainRW test100 = new mainRW(function, 100, F, CR, NP, MaxFes100, runs, folderExpd100, ms[i]);
            //mainRW test500 = new mainRW(function, 500, F, CR, NP, MaxFes500, runs, folderExpd500, ms[i]);
            //mainRW test1000 = new mainRW(function, 1000, F, CR, NP, MaxFes1000, runs, folderExpd1000, ms[i]);
            //test1000.run();
            
            
            try{
                
                pool.execute(test100);
                //pool.execute(test500); 
                //pool.execute(test1000);
            
            }catch(Exception ex){
                ex.printStackTrace();
                System.out.println(ex.getMessage());
            }
            
            long t1 = System.currentTimeMillis();
            
            do {
                System.out.printf("Main: Active Threads: %d\n", pool.getActiveThreadCount());
                System.out.printf("Time: %d\n", (((System.currentTimeMillis()-t1)/1000)));
                try {
                    TimeUnit.MINUTES.sleep(5);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (
                     !test100.isDone() 
                     //!test500.isDone()
                     // !test1000.isDone()
                    );
        }
    }

    public void runexp(int[] function, int dimension, double F, double CR, int NP, int MaxFes, int runs, String folder, int m) {
        for (int i = 0; i < function.length; i++) {
            IFunctionEvaluation f = new FunctionsSayed(function[i], dimension);
            ExperimentRuns er4 = new ExperimentRuns(folder, "AlgorithmName", f.getFunctionName());
            for (int e = 0; e < runs; e++) {
                System.out.println("Function: " + f.getFunctionName() + " Run: " + e);
                
                DELOCOS_RW mdde4 = new DELOCOS_RW(this.F, this.CR, this.NP, this.MaxFes, this.dimension, m);
                er4.setAlgorithmName(mdde4.getName());
                
                mdde4.setFunction(f);
                
                RunResults r4 = mdde4.run();
                System.out.println("Function: " + f.getFunctionName() + " Run: " + e +"\n");
                System.out.println(Arrays.toString(r4.getFinalbestF()));
                er4.addRunResult(r4);
                
            }
            er4.exportData();
        }
    }

    public void run() {
        runexp(function, dimension, F, CR, NP, MaxFes, runs, folder, m);
    }

    @Override
    public Object getRawResult() {
        return null;
    }

    @Override
    protected void setRawResult(Object value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected boolean exec() {
        this.run();
        return true;
    }

}

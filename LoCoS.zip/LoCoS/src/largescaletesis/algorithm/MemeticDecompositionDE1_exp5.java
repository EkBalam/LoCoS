package largescaletesis.algorithm;

import evoutils.algorithms.DE.CrossOver;
import evoutils.algorithms.DE.Mutations;
import evoutils.algorithms.IBasicAlgorithm;
import evoutils.functions.IFunctionEvaluation;
import evoutils.solutions.Solution;
import evoutils.solutions.population.Population;
import evoutils.utils.Utils;
import evoutils.utils.VectorOperations;
import largescaletesis.experiment.ExperimentRuns;
import largescaletesis.experiment.RunResults;
import largescaletesis.functions.constrained.FunctionsSayed;
import java.util.Arrays;
import java.util.LinkedList;
import largescaletesis.algorithm.localsearch.HookeJeevesM;
import largescaletesis.algorithm.localsearch.LocalSearchResult;


/**
 * Experiment five, same that experiment 4, indexs from decomposition are sort
 * and the local search is realized by subgroup
 *
 * @author EkBalam
 */
public class MemeticDecompositionDE1_exp5 implements IBasicAlgorithm {

    private String name = "DE-LoCoS";
    private IFunctionEvaluation function = null;

    private final double F, CR;
    private final int NP;
    private final int MaxFes;
    private final int dimension;

    private int c;
    private int fes;

    private VIIC_O viic;
    private int m = 2;
    //private ArrayList<Solution> pop;
    private Population pop;

    private long time;
    boolean finish = false;

    private HookeJeevesM localS;

    //Results 
    public RunResults results;
    public LinkedList<Solution> betterSolutions;
    double convergenceMeasure = -1;

    public MemeticDecompositionDE1_exp5(double F, double CR, int SN, int MaxFes, int dimension, int m) {
        this.F = F;
        this.CR = CR;
        this.NP = SN;
        this.MaxFes = MaxFes;
        this.dimension = dimension;
        //this.pop = new ArrayList<>();
        this.pop = new Population(this.NP);
        this.time = 0;
        this.finish = false;
        this.betterSolutions = new LinkedList<>();
        this.results = new RunResults();
        this.m = m;
    }

    public RunResults run() {
        this.runAlgorithm();
        return this.results;
    }

    @Override
    public void runAlgorithm() {

        this.time = System.currentTimeMillis();

        fes = this.NP;
        int fesGlobal = this.NP;
        int localFEs = 0;

        int MaxLocalFEs = (int) (this.MaxFes * 0.3);
        int fesApplyLocal = (int) ((4 * this.dimension) / (0.3 * this.NP));
        int vecesAplicado = 0;
        System.out.println("APLICAR CADA " + fesApplyLocal + " Ciclos");

        this.pop.initializePop(function);

        this.betterSolutions.add(this.pop.getBest().clone());
        //System.out.println(this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());

        c = 1;
        while ((fes < this.MaxFes) && (!finish)) {

            //this.results.setConvergenceANDnewF(this.calculateConvergence());

            Population popg = new Population(this.NP);
            int i = 0;

            while (i < this.NP && (!finish)) {

                Solution x = this.pop.getAt(i);
                Solution xg = rand1binOp(i);
                fes++;
                fesGlobal++;

                if (x.compareTo(xg) < 0) {
                    popg.replaceAt(i, x);
                } else {
                    popg.replaceAt(i, xg);
                }

                if (fes == this.MaxFes) {
                    finish = true;
                }
                i++;

            }

            if (finish && (i < this.NP)) {
                for (int j = i; j < this.NP; j++) {
                    popg.replaceAt(j, this.pop.getAt(j));
                }
            }
            this.pop = popg;

            //LOCAL SEARCH PHASE
            if (localFEs < MaxLocalFEs && (c % fesApplyLocal == 0) && (!finish)) {
                int fesls = this.localSearchPhase(this.pop.getBestIndex(), fes);
                fes += fesls;
                localFEs += fesls;
                vecesAplicado++;
            }

            //System.out.println(this.function.getFunctionName());
            this.betterSolutions.add(this.pop.getBest().clone());

            this.results.addBestG(this.betterSolutions.getLast().getF(), this.betterSolutions.getLast().getSvr());

//            System.out.print("Best: ");
//            System.out.print(this.betterSolutions.getLast().getF() + " --- " + this.betterSolutions.getLast().getSvr());
//            System.out.print(" Worts: ");
//            System.out.print(this.pop.getWorst().getF() + " --- " + this.pop.getWorst().getSvr());
//            System.out.println(" FES: "+fes +" viic: "+this.viic.getGprsPool().size());
            c++;
        }

        this.time = System.currentTimeMillis() - this.time;

        Solution best = this.pop.getBest();

        System.out.println("Final FES :" + fes + " FES Global = " + fesGlobal + " Fes local :" + localFEs + " Final Cycles: " + c);
        System.out.println("Local Aplicado :" + vecesAplicado + " Promedio Evals Locales = " + localFEs / vecesAplicado);
        System.out.println("Tiempo = " + (this.time / 1000) + " seg.");
        System.out.println("VIIC POOL = "+this.viic.getGprsPool().size());
        System.out.println(this.c);
        
        System.out.println(best);

        //System.out.println(time / 1000);
        this.results.setFinalX(best.getX());
        this.results.setFinalbestF(best.getF(), best.getSvr());
//        this.results.setGlobalFes(fesGlobal);
//        this.results.setLocalFes(localFEs);
//        this.results.setViiCconstraintsFes(this.viic.getEvalsConstraints());
//        this.results.setViiCfunctionFes(this.viic.getEvalsObjectiveFunction());
        this.results.setTime(time);
    }

    private Solution rand1binOp(int i) {
        int ng = this.function.getNumberIConstraints();
        int nh = this.function.getNumberEConstraints();

        int[] perm = Utils.randperm(this.NP);
        Solution x = this.pop.getAt(i);
        Solution r1 = this.pop.getAt(perm[0]);
        Solution r2 = this.pop.getAt(perm[1]);
        Solution r3 = this.pop.getAt(perm[2]);

        double[] v = Mutations.rand1(this.F, r1.getX(), r2.getX(), r3.getX());
        double[] target = x.getX();
        double[] trial = CrossOver.binomial(target, v, CR);
        trial = Utils.boundaryHandling(trial, function.getLimits());
        Solution r = new Solution(dimension, ng, nh);
        r.setX(trial);
        this.function.evaluate(r);
        return r;
    }

    @Override
    public void setFunction(IFunctionEvaluation function) {
        this.function = function;
        this.localS = new HookeJeevesM(2, this.MaxFes, this.function);
        //this.viic = new VIIC(this.m, (FunctionsSayed) this.function);
        this.viic = new VIIC_O(this.m, (FunctionsSayed) this.function);
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public long getTime() {
        return time;
    }

    private int localSearchPhase(int index, int fes) {

        Solution s = this.pop.getAt(index);

        boolean feasible = s.getSvr() <= 0;

        int[] variables;//= new int[this.dimension];

        if ((this.c < 25 || this.viic.getrandGprspool() == null || (c % 50 == 0)
                && (this.fes < (this.MaxFes / 2)) || (this.c % 100 == 0)
                && (this.viic.getGprsPool().size() < 100))) {
            
            long timeDecomposition = System.currentTimeMillis();
            
            variables = this.viic.getDecomposition(feasible);
            timeDecomposition = System.currentTimeMillis()-timeDecomposition;
            System.out.println("Time decomposition = "+timeDecomposition);
            
        } else {
            variables = this.viic.getrandGprspool();
        }

        //Calculate the steps size of each variable for HJ
        double[] delta = this.createDeltaHJ();

        int[] variablesSubgroups = this.viic.getV();

        int from = 0;
        int to = 0;
        int fesWasted = 0;

        Solution sclone = s.clone();
        //System.out.println("IN: " + sclone.getF() + " --- " + sclone.getSvr());

        for (int sg = 0; sg < variablesSubgroups.length; sg++) {
            to = from + variablesSubgroups[sg];

            int[] varSub = Arrays.copyOfRange(variables, from, to);

            LocalSearchResult lsresult = localS.localSearch(sclone, varSub, delta, (fes + fesWasted));

            //revisar bien el paro por alcanzar el maximo de evaluaciones gastadas.
            fesWasted += lsresult.FEs;
            this.finish = this.finish != true ? lsresult.finish : this.finish;
            from = from + variablesSubgroups[sg];

            //cambiar las variables por las nuevas encontradas si se mejoro la solucion.
            if (lsresult.result.compareTo(sclone) <= 0) {
                sclone = lsresult.result;
                //System.out.println("M = " + sg + " OUT: " + lsresult.result.getF() + " --- " + lsresult.result.getSvr() + " --- FES LS: " + lsresult.FEs);
            }
        }

        if (sclone.compareTo(s) <= 0) {
            this.pop.replaceAt(index, sclone);
            //System.out.println("OUT: " + sclone.getF() + " --- " + sclone.getSvr() + " --- FES LS: " + fesWasted);
        }
        return fesWasted;
    }

    private double[] createDeltaHJ() {
        return standartDeviationVariables();
    }

    private double[] standartDeviationVariables() {

        double[] desv = new double[this.function.getDimension()];

        for (int i = 0; i < this.function.getDimension(); i++) {
            double[] data = new double[this.NP];
            for (int j = 0; j < this.NP; j++) {
                Solution s = this.pop.getAt(j);
                data[j] = s.getX()[i];
            }
            desv[i] = Utils.getStatistics(data)[3];
        }

        return desv;
    }

    private double calculateConvergence() {
        double[] stds = this.standartDeviationVariables();
        if (this.convergenceMeasure < 0) {
            this.convergenceMeasure = VectorOperations.sum(stds);
            return 1;
        } else {
            return (VectorOperations.sum(stds) / this.convergenceMeasure);
        }
    }

    public static void main(String[] args) {
        int function = 1;

        int dimension = 100;
        int m = 2;

        double F = 0.5, CR = 0.9;
        int NP = 100;
        int MaxFes = 2000000;

        int runs = 1;

        IFunctionEvaluation f = new FunctionsSayed(function, dimension);
        ExperimentRuns exRuns100 = new ExperimentRuns("./testNewExport100/", "imviic100", f.getFunctionName());
//        ExperimentRuns exRuns500 = new ExperimentRuns("./testNewExport500/", "imviic500", f.getFunctionName());
//        ExperimentRuns exRuns1000 = new ExperimentRuns("./testNewExport1000/", "imviic1000", f.getFunctionName());
      
        for (int i = 0; i < runs; i++) {
            MemeticDecompositionDE1_exp5 mdde = new MemeticDecompositionDE1_exp5(F, CR, NP, MaxFes, dimension, m);
            mdde.setFunction(f);
            RunResults r4 = mdde.run();
            System.out.println(Arrays.toString(r4.getFinalbestF()));
           // exRuns100.addRunResult(r4);
                        
//            MemeticDecompositionDE1_exp5 mdde500 = new MemeticDecompositionDE1_exp5(F, CR, NP, 10000000, 500, m);
//            mdde.setFunction(f);
//            RunResults r5 = mdde500.run();
//            System.out.println(Arrays.toString(r5.getFinalbestF()));
//            exRuns500.addRunResult(r5);
//            
//            
//            MemeticDecompositionDE1_exp5 mdde1000 = new MemeticDecompositionDE1_exp5(F, CR, NP, 20000000, 1000, m);
//            mdde.setFunction(f);
//            RunResults r6 = mdde1000.run();
//            System.out.println(Arrays.toString(r6.getFinalbestF()));
//            exRuns500.addRunResult(r6);
            
        }
//        exRuns100.exportData();
//        exRuns500.exportData();
//        exRuns1000.exportData();
    }

}

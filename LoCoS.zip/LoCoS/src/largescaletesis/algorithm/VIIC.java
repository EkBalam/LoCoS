/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm;

import evoutils.functions.IFunctionEvaluation;
import evoutils.utils.Utils;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import largescaletesis.functions.constrained.BasicFunctionsSayed;
import largescaletesis.functions.constrained.FunctionsSayed;

/**
 *
 * @author EkBalam
 */
public class VIIC {

    /**
     * 
     */
    private int max_constr;
    /**
     * Max iterations of optimising each subproblem
     */
    private final int max_gprsiter;
    /**
     * size of each subproblem
     */
    private int[] V;
    /**
     * subproblems
     */
    private int m;
    /**
     * is expected to have a reasonable number of different variables arrangements
     */
    private LinkedList<int[]> gprsPool;

    FunctionsSayed function;

    private int dimension;
    private int evalsConstraints;
    private int evalsObjectiveFunction;


    public VIIC(int m, FunctionsSayed function) {
        this.m = m;
        this.function = function;
        this.dimension = function.getDimension();
        this.max_gprsiter = this.m * 10000;
        this.gprsPool = new LinkedList<>();
        this.createV();
        this.evalsConstraints = 0;
        this.evalsObjectiveFunction = 0;
    }

    public int[] getDecomposition(boolean feasible) {

        this.evalsObjectiveFunction = 0;
        int functionEval = this.function.getNumberIConstraints();
        max_constr = functionEval + 1;
        int c_num = 1;
        if (feasible) {
            c_num = 0;
        }

        //Frecuency Matrix
        LinkedList<int[]> FM = new LinkedList<>();
        
        double C1 = Utils.randInterval(1, this.function.getLimits()[IFunctionEvaluation.UPPER_LIMIT][0]);
        double C2 = Utils.randInterval(1, this.function.getLimits()[IFunctionEvaluation.UPPER_LIMIT][0]);
        
        while (c_num < max_constr) {
            
            int[] Sg = Utils.randperm(this.dimension);
            double fitallc1c2 = calculateFitallC1C2(C1, C2, c_num);
            double fitgroupsc1c2 = calculateFitGroupsC1C2(Sg, C1, C2, c_num);
            double grpsdiff = Math.abs(fitallc1c2 - fitgroupsc1c2);
            int grpiter = 0;
            while (grpsdiff != 0 && grpiter < this.max_gprsiter) {
                int[] Sg1 = Utils.randperm(this.dimension);
                fitgroupsc1c2 = calculateFitGroupsC1C2(Sg1, C1, C2, c_num);
                double grpsdiffnew = Math.abs(fitallc1c2 - fitgroupsc1c2);
                if (grpsdiffnew < grpsdiff) {
                    grpsdiff = grpsdiffnew;
                    Sg = Sg1;
                }
                grpiter++;
            }
            FM.add(Sg);
            c_num++;
        }

        int[] Sn = createSN(FM);
        
        Sn = this.sortSubProblemIndex(Sn);
        
        this.gprsPool.add(Sn);

        return Sn;
    }

    /**
     * 
     * @param FM 
     * @return The variable arrangement vector SN
     */
    private int[] createSN(LinkedList<int[]> FM) {

        LinkedList<Integer> Sn = new LinkedList<>();

        class IndexValue {

            public int index = 0;
            public int value = 0;

            public IndexValue(int index) {
                this.index = index;
            }

        }

        LinkedList<IndexValue> count = new LinkedList<>();

        for (int i = 0; i < this.function.getDimension(); i++) {
            count.add(new IndexValue(i));
        }

        int start = 0;
        int end = 0;

        //For every subgroup
        for (int k = 0; k < m; k++) {

            end = start + V[k];

            //Count the number of aparitons of each variable
            for (int i = start; i < end; i++) {
                for (int[] s : FM) {
                    for (int j = 0; j < count.size(); j++) {
                        if(count.get(j).index == s[i]){
                            count.get(j).value++;
                        }
                    }
                }
            }
            
            Collections.sort(count,(IndexValue o1, IndexValue o2) -> {
                if (o1.value < o2.value) {
                    return 1;
                }
                if (o1.value > o2.value) {
                    return -1;
                }
                return 0;
            });
            
            //for (int i = 0; i < V[k]; i++) {
            int i = 0;
            while(!count.isEmpty() && i < V[k]){
                IndexValue var = count.getFirst();
                Sn.add(var.index);
                count.removeFirst();
                i++;
            }
            
            for (IndexValue var:count) {
                var.value = 0;
            }
            
            start = end;
        }
        
        //System.out.println(Sn.size());
        //System.out.println(allDifferent(Sn));

        int[] r = new int[this.dimension];
        for (int i = 0; i < this.dimension; i++) {
            r[i] = Sn.get(i);
        }

        return r;
    }

    private double calculateFitGroupsC1C2(int[] Sg, double C1, double C2, int c_num) {
        double fitgroups = 0.0;

        for (int k = 0; k < this.m; k++) {
            double[] xc1 = new double[dimension];
            double[] xc2 = new double[dimension];
            for (int i = 0; i < dimension; i++) {
                xc1[i] = C2;
                xc2[i] = C1;
            }

            int start = 0;
            if (k != 0) {
                for (int i = 0; i < k; i++) {
                    start += V[i];
                }
            }
            int end = V[k] + start;

            for (int j = start; j < end; j++) {
                xc1[Sg[j]] = C1;
                xc2[Sg[j]] = C2;
            }

            fitgroups += evalfunctionC1C2(c_num, xc1) + evalfunctionC1C2(c_num, xc2);
        }

        return fitgroups;
    }

    private double calculateFitallC1C2(double C1, double C2, int c_num) {
        double xc1[] = new double[dimension];
        double xc2[] = new double[dimension];
        double fitc1;
        double fitc2;

        for (int i = 0; i < dimension; i++) {
            xc1[i] = C1;
            xc2[i] = C2;
        }

        fitc1 = evalfunctionC1C2(c_num, xc1);
        fitc2 = evalfunctionC1C2(c_num, xc2);

        return this.m * (fitc1 + fitc2);
    }

    private double evalfunctionC1C2(int c_num, double[] xc) {
        double f = 0.0;
        switch (c_num) {
            case 1:
                f = BasicFunctionsSayed.g01(xc);
                this.evalsConstraints++;
                break;
            case 2:
                f = BasicFunctionsSayed.g02(xc);
                this.evalsConstraints++;
                break;
            case 3:
                f = BasicFunctionsSayed.g03(xc);
                this.evalsConstraints++;
                break;
            case 0:
                f = this.evalFunction(xc);
                this.evalsObjectiveFunction++;
                break;
        }
        return f;
    }

    /**
     * 
     * @return an array with the size of each subproblem
     */
    public int[] getV() {
        return V;
    }

    /**
     * 
     * @return a random decomposition vector from the gprsPool
     */
    public int[] getrandGprspool() {
        if(this.gprsPool.size() > 0){
            int s = Utils.randInt(gprsPool.size());
            return gprsPool.get(s);
        }
        return null;
    }

    public LinkedList<int[]> getGprsPool() {
        return gprsPool;
    }
    
    private void createV() {
        int t = (int) Math.ceil((double) this.dimension / (double) this.m);
        //Math.round(this.dimension / this.m);
        V = new int[m];
        int sum = 0;
        for (int i = 0; i < m; i++) {
            if (sum + t > dimension || i + 1 == m) {
                V[i] = dimension - sum;
            } else {
                V[i] = t;
                sum += t;
            }
        }
    }

    private double evalFunction(double[] xc) {
        int f = this.function.getFunction();
        double fit = 0.0;
        switch (f) {
            case 1: case 2: case 3:
                fit = BasicFunctionsSayed.obj1(xc);
                break;
            case 4: case 5: case 6:
                fit = BasicFunctionsSayed.obj2(xc);
                break;
            case 7: case 8: case 9:
                fit = BasicFunctionsSayed.obj3(xc);
                break;
            case 10: case 11: case 12:
                fit = BasicFunctionsSayed.obj4(xc);
                break;
            case 13: case 14: case 15:
                fit = BasicFunctionsSayed.obj5(xc);
                break;
            case 16: case 17: case 18:
                fit = BasicFunctionsSayed.obj6(xc);
                break;
        }
        return fit;
    }
    
    
    public int getEvalsConstraints() {
        return evalsConstraints;
    }

    public int getEvalsObjectiveFunction() {
        return evalsObjectiveFunction;
    }

    private boolean allDifferent(LinkedList<Integer> Sn) {
        boolean alldiferents = true;
        for (int x = 0; x < Sn.size(); x++) {
            for (int z = 0; z < Sn.size(); z++) {
                if (x != z) {
                    if (Sn.get(x).equals(Sn.get(z))) {
                        alldiferents = false;
                        break;
                    }
                }
            }
            if (!alldiferents) {
                break;
            }
        }
        return alldiferents;
    }
    
    private int[] sortSubProblemIndex(int [] Sn){
        
        int from = 0;
        int to = 0;
        
        for(int i = 0; i <this.V.length; i++){
            to = from + this.V[i];
            
            Arrays.sort(Sn,from,to);
            
            from = from + this.V[i];
        }

        return Sn;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largescaletesis.algorithm.differentialgrouping2;

import evoutils.functions.IFunctionEvaluation;
import evoutils.functions.largescaleSayed.FunctionsSayed;
import evoutils.solutions.Solution;
import evoutils.utils.VectorOperations;
import java.util.Arrays;
import java.util.LinkedList;
import viicstay.VIICSearch;
import viicstay.VIICeval;
import viicstay.representation.Dvector;

/**
 *
 * @author EkBalam
 */
public class DifferentialGrouping2 {
    
    IFunctionEvaluation function;
    
    public int [][] tetha;    //Binary Design Structure Matrix
    double[][] lambda; //Interaction Structure Matrix
    double[][] F;      //matrix of all NaNs
    double[] f;        //Vector of all NaNs
    double fbase;
    int gamma;
    
    
    public DifferentialGrouping2(IFunctionEvaluation function){
        this.function = function;
        
        int n = this.function.getDimension();
        this.lambda = new double[n][n];
        this.tetha = new int[n][n];
        this.F = new double[n][n];
        this.f = new double[n];
        
        for(int i = 0; i < n; i++){
            this.f[i] = Double.NaN;
            for(int j = 0; j < n; j++){
                this.F[i][j] = Double.NaN;
                this.tetha[i][j] = -1;
            }
        }
        
        this.ISM();
        this.DSM();
    }
    
    public Dvector grouping(){
        int dimension = this.function.getDimension();
        int [] group = this.groups(this.tetha, dimension);
        Dvector s = new Dvector(dimension);
        s.setVarArrGroup(group);
        return s;
    }
    
    private void ISM(){
        double[] upperLimit = this.function.getLimits()[1];
        double[] lowerLimit = this.function.getLimits()[0];
        int n = this.function.getDimension();
        
        double fp1, fp2, fp3, fp4;
        
        double[] x1 = Arrays.copyOf(lowerLimit,n);
        this.fbase = this.evaluateVector(x1);
        fp1 = this.fbase;
        
        this.gamma = 1;       
        
        double[] m = VectorOperations.div(VectorOperations.sum(upperLimit,lowerLimit), 2);
        
        for(int i = 0; i < n-1; i++){
            
            if(!Double.isNaN(this.f[i])){
                fp2 = f[i];
            }else{
                double[] x2 = Arrays.copyOf(x1, n);
                x2[i] = m[i];
                fp2 = this.evaluateVector(x2);
                this.f[i] = fp2;
                this.gamma++;
            }
            
            for(int j = i + 1; j < n; j++){
                if(!Double.isNaN(this.f[j])){
                    fp3 = this.f[j];
                }else{
                    double[] x3 = Arrays.copyOf(x1, n); 
                    x3[j] = m[j];
                    fp3 =  this.evaluateVector(x3);
                    this.f[j] = fp3;
                    this.gamma++;
                }
                
                double[] x4 = Arrays.copyOf(x1, n); 
                x4[i] = m[i]; 
                x4[j] = m[j];
                fp4 = this.evaluateVector(x4); this.gamma++;
                this.F[i][j] = fp4;
                this.F[j][i] = fp4;
                
                double delta1 = fp2 - fp1;
                double delta2 = fp4 - fp3;
                
                this.lambda[i][j] = Math.abs(delta1 - delta2);
                this.lambda[j][i] = Math.abs(delta1 - delta2);
            }
            
        }
        
    }
    
    private void DSM(){
        int eta1 = 0,eta2 = 0;
        int n = this.function.getDimension();
        
        for(int i = 0; i < n-1; i++){
            for(int j = i; j < n; j++){
                double fmax = this.max(this.fbase, this.F[i][j], this.f[i], this.f[j]);
                double epsilon_inf = this.gammaFunc(2) * 
                        this.max(this.fbase+this.F[i][j], this.f[i]+this.f[j]);
                double epsilon_sup = this.gammaFunc(1) * Math.sqrt(n) * fmax;
                
                if(this.lambda[i][j] < epsilon_inf){
                    this.tetha[i][j] = 0;
                    this.tetha[j][i] = 0;
                    eta1++;
                }else if(this.lambda[i][j] > epsilon_sup){
                    this.tetha[i][j] = 1; 
                    this.tetha[j][i] = 1; 
                    eta2++;
                }
            }
        }
        
        for(int i = 0; i < n-1; i++){
            for(int j = i; j < n; j++){
                double fmax = this.max(this.fbase, this.F[i][j], this.f[i], this.f[j]);
                double epsilon_inf = this.gammaFunc(2) * 
                        this.max(this.fbase+this.F[i][j], this.f[i]+this.f[j]);
                double epsilon_sup = this.gammaFunc(Math.sqrt(n))  * fmax;
                
                if(this.tetha[i][j] != -1){
                    double epsilon = (eta1/(eta1+eta2)) * epsilon_inf + 
                                     (eta2/(eta1+eta2)) * epsilon_sup;
                    if(this.lambda[i][j] > epsilon){
                        this.tetha[i][j] = 1;
                        this.tetha[j][i] = 1;
                    }else{
                        this.tetha[i][j] = 0;
                        this.tetha[j][i] = 0;
                    }
                }
            }
        }
        
    }
    
    public int[] groups(int [][] tetha, int n){
        
        LinkedList<Integer> variables = new LinkedList<>();
        LinkedList<Integer> visitando = new LinkedList<>();
        
        for(int i = 0; i < n; i++){
            variables.add(i);
        }
        
        int[] group = new int[n];
        
        int G = 0;
        
        while(!variables.isEmpty()){
            G++;
            int var = variables.pop();
            visitando.add(var);
            
            while(!visitando.isEmpty()){
                var = visitando.pop();
                group[var] = G;
                for(int j = 0; j < n; j++){
                    if(tetha[var][j] == 1){       
                        if(variables.contains(j)){
                            visitando.add(j);
                            variables.remove(new Integer(j));
                        }
                    }
                }
            }
        }

        System.out.println("ConnComp = "+ G);
        return group;
    }
    
    private double gammaFunc(double d){
        double muM = Math.ulp(1)/2.0;
        return (d * muM)/(1.0-(d*muM));
    }
    
    private double evaluateVector(double[] x){
        Solution s1 = new Solution(this.function.getDimension(),this.function.getNumberIConstraints(),this.function.getNumberEConstraints());
        s1.setX(x);
        s1 = this.function.evaluate(s1);
        return s1.getF() + s1.getSvr();
    }
 
    public double max(double... x){
        int length = x.length;
        double maxv = x[0];
        if (length > 1) {
            for (int i = 1; i < length; i++) { 
                maxv = x[i] > maxv ? x[i] : maxv;
            }
        }
        return maxv;
    }
    
    public static void main(String[] args) {
        int dimension = 1000;   
        
        for(int i = 1; i < 19; i++){
            
            FunctionsSayed function = new FunctionsSayed(i, dimension);
            //IFunctionEvaluation function = new LSGO2013functions(1,dimension);
            //IFunctionEvaluation function = new SuiteCeC2006(1);
            //dimension = function.getDimension();
            //IFunctionEvaluation function = new SuiteCeC2010(1, dimension);
            DifferentialGrouping2 dg2 = new DifferentialGrouping2(function);

    //        System.out.println(dg2.gamma);
    //        System.out.println("Gamma 1: "+dg2.gammaFunc(1));
    //        System.out.println("Gamma 2: "+dg2.gammaFunc(2));
    //        System.out.println("Gamma D: "+dg2.gammaFunc(Math.sqrt(dimension)));

            int [] group = dg2.groups(dg2.tetha, dimension);

            //System.out.println(Arrays.toString(group));

            Dvector s = new Dvector(dimension);
            s.setVarArrGroup(group);
    //        
            VIICeval.BALANCEGROUPS = true;
            VIICeval viic = new VIICeval(function);
            viic.eval(s);

            System.out.println(s.getNumberSubgroups());
        }
//       VIICSearch vs = new VIICSearch(100,0.9,0.5,5051,function);    
//       vs.run(null);
//        System.out.println(vs.getBest());
        
        //for(int i = 0; i < 100; i++)
        //    System.out.println(Arrays.toString(dg2.lambda[i]));
    }
    
}
